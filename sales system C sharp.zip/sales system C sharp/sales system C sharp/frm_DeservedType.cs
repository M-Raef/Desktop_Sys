﻿ using DevExpress.XtraEditors;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sales_system_C_sharp
{
    public partial class frm_DeservedType : DevExpress.XtraEditors.XtraForm
    {
        public frm_DeservedType()
        {
            InitializeComponent();
        }

        Database_class db = new Database_class();
        DataTable tbl = new DataTable();
        //هنا عند الضغط مرتين على ال فورم مشان الرقم التلقائي
        private void AutoNumber()
        {
            tbl.Clear();
            tbl = db.readData("select max (Des_ID) from Deserved_Type", "");

            if ((tbl.Rows[0][0].ToString() == DBNull.Value.ToString()))
            {
                txtID.Text = "1";
            }
            else
            {
                txtID.Text = (Convert.ToInt32(tbl.Rows[0][0]) + 1).ToString();
            }

            txtName.Clear();

            btnAdd.Enabled = true;
            btnNew.Enabled = true;
            btnDelete.Enabled = false;
            btnDeleteAll.Enabled = false;
            btnSave.Enabled = false;

        }


        int row;
        //الان هذه الدالة من اجل عرض البيانات
        private void show()
        {
            tbl.Clear();
            tbl = db.readData("select * from Deserved_Type", "");

            if (tbl.Rows.Count <= 0)
            {
                MessageBox.Show("لا يوجد بيانات في هذه الشاشة");
            }
            else
            {
                txtID.Text = tbl.Rows[row][0].ToString();
                txtName.Text = tbl.Rows[row][1].ToString();
                
            }
            btnAdd.Enabled = false;
            btnNew.Enabled = true;
            btnDelete.Enabled = true;
            btnDeleteAll.Enabled = true;
            btnSave.Enabled = true;
        }

        private void frm_DeservedType_Load(object sender, EventArgs e)
        {
            AutoNumber();
        }

        private void btnLast_Click(object sender, EventArgs e)
        {
            tbl.Clear();
            tbl = db.readData(" select count(Des_ID) from Deserved_Type ", "");
            row = (Convert.ToInt32(tbl.Rows[0][0]) - 1);
            show();
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            tbl.Clear();
            tbl = db.readData(" select count(Des_ID) from Deserved_Type ", "");
            if (Convert.ToInt32(tbl.Rows[0][0]) - 1 == row)
            {
                row = 0;
                show();
            }
            else
            {
                row++;
                show();
            }
        }

        private void btnPrev_Click(object sender, EventArgs e)
        {

            if (row == 0)
            {
                tbl.Clear();
                tbl = db.readData(" select count(Des_ID) from Deserved_Type ", "");
                row = (Convert.ToInt32(tbl.Rows[0][0]) - 1);
                show();
            }
            else
            {
                row--;
                show();
            }
        }

        private void btnFirst_Click(object sender, EventArgs e)
        {
            row = 0;
            show();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (txtName.Text == "")
            {
                MessageBox.Show("من فضلك الرجاء ادخال انواع المصروفات!!", "تحذير");
                return;
            }
            db.exceuteData("insert into Deserved_Type values (" + txtID.Text + ",'" + txtName.Text + "' )", "تم الاضافة بنجاح");
            AutoNumber();
        }

        private void btnNew_Click(object sender, EventArgs e)
        {
            AutoNumber();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            db.readData("update Deserved_Type set Name = N'" + txtName.Text + "' where Des_ID = " + txtID.Text + " ", "تم تعديل البيانات بنجاح");
            AutoNumber();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("هل انت متأكد من مسح البيانات", "تحذير!!!", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
            {
                db.readData("delete from Deserved_Type where Des_ID = " + txtID.Text + "", "تم مسح بيانات بنجاح");
                AutoNumber();
            }
        }

        private void btnDeleteAll_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("هل انت متأكد من مسح جميع البيانات", "تحذير!!!", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
            {
                db.readData("delete from Deserved_Type ", "تم مسح  جميع البيانات بنجاح");
                AutoNumber();
            }
        }
    }
}