﻿using DevExpress.XtraEditors;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sales_system_C_sharp
{
    public partial class frm_SupplierReport : DevExpress.XtraEditors.XtraForm
    {
        public frm_SupplierReport()
        {
            InitializeComponent();
        }

        Database_class db = new Database_class();
        DataTable tbl = new DataTable();

        private void FillSupplier()
        {
            cbxSupplier.DataSource = db.readData("select * from Suppliers", "");
            cbxSupplier.DisplayMember = "Sup_Name";
            cbxSupplier.ValueMember = "Sup_ID";
        }
        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void Frm_SupplierReport_Load(object sender, EventArgs e)
        {
            FillSupplier();
            DtpDate.Text = DateTime.Now.ToShortDateString();

            //tbl.Clear();
            //the bes way to get this code , go to the you need of table in this code i will go in Supplier_Report table click right on them => script table as => select to => clipboard it will copy the code go to the query and paste him and we can fixed him
            tbl = db.readData("SELECT [Order_ID] as 'رقم الفاتورة',[Price] as 'المبلغ المدفوع',[Date] as 'تاريخ الدفع',Suppliers.Sup_Name as 'اسم المورد' FROM [dbo].[Supplier_Report] ,Suppliers where Suppliers.Sup_ID = Supplier_Report.Sup_ID\r\n", "");
            //هنا لقد نادينا المعلومات ووضعنا اسم المورد الذي نريده ان يظهر مقابل رقمه ولقد وضعناها داخل الشاشة البيضاء
            DgvSearch.DataSource = tbl;

            //اما هذا الكود من اجل جمع المبالغ ووضعه داخل اجمالي المبالغ
            decimal totalPrice = 0;
            for (int i = 0; i <= DgvSearch.Rows.Count - 1; i++)
            {
                totalPrice += Convert.ToDecimal(DgvSearch.Rows[i].Cells[1].Value);
            }
            txtTotal.Text = Math.Round(totalPrice, 2).ToString();

        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            tbl.Clear();

            if(rbtnAllSup.Checked == true)
            {
                //the bes way to get this code , go to the you need of table in this code i will go in Supplier_Report table click right on them => script table as => select to => clipboard it will copy the code go to the query and paste him and we can fixed him
                tbl = db.readData("SELECT [Order_ID] as 'رقم الفاتورة',[Price] as 'المبلغ المدفوع',[Date] as 'تاريخ الدفع',Suppliers.Sup_Name as 'اسم المورد' FROM [dbo].[Supplier_Report] ,Suppliers where Suppliers.Sup_ID = Supplier_Report.Sup_ID", "");
            }
            else if(rbtnOneSup.Checked == true)
            {
                tbl = db.readData("SELECT [Order_ID] as 'رقم الفاتورة',[Price] as 'المبلغ المدفوع',[Date] as 'تاريخ الدفع',Suppliers.Sup_Name as 'اسم المورد' FROM [dbo].[Supplier_Report] ,Suppliers where Suppliers.Sup_ID = Supplier_Report.Sup_ID and Suppliers.Sup_ID= "+cbxSupplier.SelectedValue+" ", "");
                //
            }
          //هنا لقد نادينا المعلومات ووضعنا اسم المورد الذي نريده ان يظهر مقابل رقمه ولقد وضعناها داخل الشاشة البيضاء
            DgvSearch.DataSource = tbl;

            //اما هذا الكود من اجل جمع المبالغ ووضعه داخل اجمالي المبالغ
            decimal totalPrice = 0;
            for (int i = 0; i <= DgvSearch.Rows.Count - 1; i++)
            {
                totalPrice += Convert.ToDecimal(DgvSearch.Rows[i].Cells[1].Value);
            }
            txtTotal.Text = Math.Round(totalPrice, 2).ToString();

        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if(DgvSearch.Rows.Count >= 1)
            {
                if (MessageBox.Show("هل انت متأكد من مسح البيانات", "تحذير!!!", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                {
                    if(rbtnOneSup.Checked == true)
                    {
                        db.exceuteData("delete from Supplier_Report where Sup_ID=" + cbxSupplier.SelectedValue + " ", "تم مسح البيانات بنجاح");
                        //هذه من اجل اعادة تحميل او احضار الشاشة بعد الحذف
                        Frm_SupplierReport_Load(null, null);
                    }
                    else { MessageBox.Show("من فضلك حدد مورد اولا", "تاكيد");return; }
                }

            }
           
        }
    }
}