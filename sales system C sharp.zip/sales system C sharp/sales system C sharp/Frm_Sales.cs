﻿using DevExpress.XtraEditors;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sales_system_C_sharp
{
    public partial class Frm_Sales : DevExpress.XtraEditors.XtraForm
    {

        //هذه الدالة عبارة عن انه تسمحلي بنقل المعلومات من شاشة الى شاشة اخرى داخل تشغيل البرنامج
        private static Frm_Sales frm;
        static void frm_FormClosed(object sender, FormClosedEventArgs e)
        {
            frm = null;
        }
        public static Frm_Sales GetFormSales
        {
            get
            {
                if (frm == null)
                {
                    frm = new Frm_Sales();
                    frm.FormClosed += new FormClosedEventHandler(frm_FormClosed);
                }
                return frm;
            }
        }

        public Frm_Sales()
        {
            InitializeComponent();
            //هنا يقول ازا الدالة يلي فوق فاضية يسوي بس العملية هون
            if (frm == null)
                frm = this;
        }
        Database_class db = new Database_class();
        DataTable tbl = new DataTable();
        //هذه الدالة من اجل ملئ العناصر 
        private void FillItems()
        {
            cbxItems.DataSource = db.readData("select * from Products", "");
            cbxItems.DisplayMember = "Pro_Name";
            cbxItems.ValueMember = "Pro_ID";
        }

        //هنا سويناها بابلك من اجل استخدامها في frm_suppliers
        //من اجل مناداة المعلومات
        public void FillCustomer()
        {
            cbxCustomer.DataSource = db.readData("select * from Customers", "");
            cbxCustomer.DisplayMember = "Cust_Name";
            cbxCustomer.ValueMember = "Cust_ID";
        }

        private void Frm_Sales_Load(object sender, EventArgs e)
        {
            FillItems();
            FillCustomer();

            //هنا جالس اقله التواريخ يلي هون اعملي ياهن على تاريخ اليوم
            DtpDate.Text = DateTime.Now.ToShortDateString();
            DtpReminder.Text = DateTime.Now.ToShortDateString();

            //معناها ان ينفذ العملية التابعة اله
            rbtnCustNakdy_CheckedChanged(null, null);

            try
            {
                AutoNumber();
            }catch(Exception ) { }
        }

        private void AutoNumber()
        {
            tbl.Clear();
            tbl = db.readData("select max (Order_ID) from Sales", "");

            if ((tbl.Rows[0][0].ToString() == DBNull.Value.ToString()))
            {
                txtID.Text = "1";
            }
            else
            {
                txtID.Text = (Convert.ToInt32(tbl.Rows[0][0]) + 1).ToString();
            }
            DtpDate.Text = DateTime.Now.ToShortDateString();
            DtpReminder.Text = DateTime.Now.ToShortDateString();

            try
            {
                cbxItems.SelectedIndex = 0;
                cbxCustomer.SelectedIndex = 0;
            }
            catch (Exception) { }
            cbxItems.Text = " اختر منتج ";
            DgvSale.Rows.Clear();
            rbtnCustNakdy.Checked = true;
            txtbarcode.Clear();
            //من اجل يسولها فوكس يعني لما اختار تضل الماوس هنيك
            txtbarcode.Focus();
            txtTotal.Clear();

        }


        private void rbtnCustNakdy_CheckedChanged(object sender, EventArgs e)
        {
            //هنا لما نحط على عميل نقدي رح يسكر الازرار يلي التحت وسوينا العكس بالعميل الاجل
            try
            {
                cbxCustomer.Enabled = false;
                btnCustomerBrowes.Enabled = false;
                DtpReminder.Enabled = false;

            }catch (Exception ) { }
        }

        private void rbtnCustAagel_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                cbxCustomer.Enabled = true;
                btnCustomerBrowes.Enabled = true;
                DtpReminder.Enabled = true;

            }
            catch (Exception) { }
        }

        private void btnCustomerBrowes_Click(object sender, EventArgs e)
        {
            frm_customers frm = new frm_customers();
            frm.ShowDialog();

        }

        private void btnItems_Click(object sender, EventArgs e)
        {
            if (cbxItems.Text == " اختر منتج ")
            {
                MessageBox.Show("من فضلك اختر منتج", "تاكيد", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            if (cbxItems.Items.Count <= 0)
            {

                MessageBox.Show("من فضلك اختر النتجات اولا", "تاكيد", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            //(Products) هنا عند اختيار اي من المنتجات رح يتم عرض معلومات المنتجات بالتفصيل الموجودة في خانة 
            DataTable tblItem = new DataTable();
            tblItem.Clear();

            tblItem = db.readData("select * from Products where Pro_ID= " + cbxItems.SelectedValue + " ", "");
            if (tblItem.Rows.Count >= 1)
            {
                try
                {
                    string Product_ID = tblItem.Rows[0][0].ToString();
                    string Product_Name = tblItem.Rows[0][1].ToString();
                    string Product_Qty = "1";//من اجل الكمية انها تكون دائما واحد ورح نسمح بتعديل الكمية لاحقا من اجل شراء الكمية التي اريدها
                    string Product_Price = tblItem.Rows[0][4].ToString();
                    decimal Discount = 0;

                    decimal total = Convert.ToDecimal(Product_Qty) * Convert.ToDecimal(tblItem.Rows[0][4]);

                    DgvSale.Rows.Add(1);
                    int rowindex = DgvSale.Rows.Count - 1;
                    //هنا بسبب ال انديكس قمنا بتنقيص واحد
                    DgvSale.Rows[rowindex].Cells[0].Value = Product_ID;
                    //سيل يلي هو الخلية يلي هو العامود ب (د ج ف) من اجل عرض البيانات يلي خزنتها جوا الكويري يلي في الاعلى
                    DgvSale.Rows[rowindex].Cells[1].Value = Product_Name;
                    DgvSale.Rows[rowindex].Cells[2].Value = Product_Qty;
                    DgvSale.Rows[rowindex].Cells[3].Value = Product_Price;
                    DgvSale.Rows[rowindex].Cells[4].Value = Discount;
                    DgvSale.Rows[rowindex].Cells[5].Value = total;
                }
                catch (Exception) { }


                try
                {
                    //هذا الكود من اجل عرض الاجمالي او جمع الاجمالي ليحطهم تحت في الاجمالي تبعهم
                    decimal TotalOrder = 0;
                    for (int i = 0; i <= DgvSale.Rows.Count - 1; i++)
                    {
                        TotalOrder += Convert.ToDecimal(DgvSale.Rows[i].Cells[5].Value);
                        //هاد الكود رح يكون عند اضافة منتج الخط الاصفر رح يكون على الخانة المضافة جديدا
                        DgvSale.ClearSelection();
                        DgvSale.FirstDisplayedScrollingRowIndex = DgvSale.Rows.Count - 1;
                        DgvSale.Rows[DgvSale.Rows.Count - 1].Selected = true;

                    }
                    txtTotal.Text = Math.Round(TotalOrder, 2).ToString();
                    //هنا لقد جمعنا الاجمالي ووضعناه في اجمالي المطلوب وهذه ال ماث راوند من اجل وضع فاصلة والارقام التي بعد الفاصلة 2 فقط
                    lblItemscount.Text = (DgvSale.Rows.Count).ToString();
                    //هذه من اجل تعديل عدد الاصناف وطبعا كل هذه العمليات نحن نريد تحقيقها عند الضغط على الزر التنزيل يلي جنب اختر منتج

                }
                catch (Exception) { }


            }
        }
        private void UpdateQty()
        {
            if (DgvSale.Rows.Count >= 1)
            {
                //حطينا هون متغير هو يلي يحط او يبدل القيم لان ممكن تواجهنا مشكلة ازا عدلنا وبعدين بدنا نضيف فممكن تواجهنا فمشان هيك عملنا هاد الكود ورح نعدله بشاشة المشتريات كمان رح خليه هيك
                int index = DgvSale.SelectedRows[0].Index;
                //الان سوف اكتب كود يممر البيانات من هنا الى الفورم تبع اف 11 ورح 
                //هنا ان نختار روز من سيل يلي هي الخانة الثانية وطبعا عند الضفط عللا اف11 رح يطلعغ على حسب ما وين انا كابس في الفارة القسم الاصفر
                Properties.Settings.Default.Item_Qty = Convert.ToDecimal(DgvSale.Rows[index].Cells[2].Value);
                Properties.Settings.Default.Item_SalePrice = Convert.ToDecimal(DgvSale.Rows[index].Cells[3].Value);
                Properties.Settings.Default.Item_Discount = Convert.ToDecimal(DgvSale.Rows[index].Cells[4].Value);
                //بهذه الطريقة سوف نحفظ الخصائص ويوجد ايضا نفسها بس بدل سيف يوجد (ريسيت) من اجل وضع المعلومات الديفولت يلي ضفتها في قائما الاعدادات في الخصائص
                Properties.Settings.Default.Save();

                Frm_SaleQty frm = new Frm_SaleQty();
                frm.ShowDialog();
            }
        }

        private void Frm_Sales_KeyDown(object sender, KeyEventArgs e)
        { 
            if (e.KeyCode == Keys.F2)
            {
                btnItems_Click(null, null);
            }
            else if (e.KeyCode == Keys.F1)
            {
                txtbarcode.Clear();
                txtbarcode.Focus();
            }
            else if (e.KeyCode == Keys.F11)
            {
                UpdateQty();
            }
            else if (e.KeyCode == Keys.F12)
            {
                PayOrder();
            }
        }

        private void PayOrder()
        {
            if(DgvSale.Rows.Count >= 1)
            {
                string d = DtpDate.Value.ToString("dd/MM/yyyy");
                string Cust_Name = "";
                if (rbtnCustAagel.Checked == true) 
                { Cust_Name = cbxCustomer.Text; }
                else
                {
                    if (txtCustomer.Text == "")
                        Cust_Name = "عميل نقدي";
                    else if(txtCustomer.Text != "")
                    {
                        Cust_Name = txtCustomer.Text;
                    }
                    
                }
                db.exceuteData("insert into Sales values ("+txtID.Text+" , '"+d+"', N'"+Cust_Name+"'  ) ","");

                for (int i = 0; i <= DgvSale.Rows.Count -1; i ++) 
                {
                    db.exceuteData("insert into Sales_Details values (" + txtID.Text+", N'"+Cust_Name+"', "+DgvSale.Rows[i].Cells[0].Value +", '"+d+"', "+ DgvSale.Rows[i].Cells[2].Value+",'123', "+DgvSale.Rows[i].Cells[3].Value+", "+ DgvSale.Rows[i].Cells[4].Value +" , "+ DgvSale.Rows[i].Cells[5].Value +", "+Properties.Settings.Default.TotalOrder+", "+ Properties.Settings.Default.Madfou3 + ", "+ Properties.Settings.Default.Bakey + " ) ", "");
                }
                AutoNumber();

            }
            
        }

        private void DgvSale_KeyDown(object sender, KeyEventArgs e)
        {
            
        }

        private void txtbarcode_KeyPress(object sender, KeyPressEventArgs e)
        {
            if(e.KeyChar == 13)
            {
                //(Products) هنا عند اختيار اي من المنتجات رح يتم عرض معلومات المنتجات بالتفصيل الموجودة في خانة 
                DataTable tblItem = new DataTable();
                tblItem.Clear();

                tblItem = db.readData("select * from Products where Barcode= '" + txtbarcode.Text + "' ", "");
                if (tblItem.Rows.Count >= 1)
                {
                    try
                    {
                        string Product_ID = tblItem.Rows[0][0].ToString();
                        string Product_Name = tblItem.Rows[0][1].ToString();
                        string Product_Qty = "1";//من اجل الكمية انها تكون دائما واحد ورح نسمح بتعديل الكمية لاحقا من اجل شراء الكمية التي اريدها
                        string Product_Price = tblItem.Rows[0][4].ToString();
                        decimal Discount = 0;

                        decimal total = Convert.ToDecimal(Product_Qty) * Convert.ToDecimal(tblItem.Rows[0][4]);

                        DgvSale.Rows.Add(1);
                        int rowindex = DgvSale.Rows.Count - 1;
                        //هنا بسبب ال انديكس قمنا بتنقيص واحد
                        DgvSale.Rows[rowindex].Cells[0].Value = Product_ID;
                        //سيل يلي هو الخلية يلي هو العامود ب (د ج ف) من اجل عرض البيانات يلي خزنتها جوا الكويري يلي في الاعلى
                        DgvSale.Rows[rowindex].Cells[1].Value = Product_Name;
                        DgvSale.Rows[rowindex].Cells[2].Value = Product_Qty;
                        DgvSale.Rows[rowindex].Cells[3].Value = Product_Price;
                        DgvSale.Rows[rowindex].Cells[4].Value = Discount;
                        DgvSale.Rows[rowindex].Cells[5].Value = total;
                    }
                    catch (Exception) { }


                    try
                    {
                        //هذا الكود من اجل عرض الاجمالي او جمع الاجمالي ليحطهم تحت في الاجمالي تبعهم
                        decimal TotalOrder = 0;
                        for (int i = 0; i <= DgvSale.Rows.Count - 1; i++)
                        {
                            TotalOrder += Convert.ToDecimal(DgvSale.Rows[i].Cells[5].Value);
                            //هاد الكود رح يكون عند اضافة منتج الخط الاصفر رح يكون على الخانة المضافة جديدا
                            DgvSale.ClearSelection();
                            DgvSale.FirstDisplayedScrollingRowIndex = DgvSale.Rows.Count - 1;
                            DgvSale.Rows[DgvSale.Rows.Count - 1].Selected = true;

                        }
                        txtTotal.Text = Math.Round(TotalOrder, 2).ToString();
                        //هنا لقد جمعنا الاجمالي ووضعناه في اجمالي المطلوب وهذه ال ماث راوند من اجل وضع فاصلة والارقام التي بعد الفاصلة 2 فقط
                        lblItemscount.Text = (DgvSale.Rows.Count).ToString();
                        //هذه من اجل تعديل عدد الاصناف وطبعا كل هذه العمليات نحن نريد تحقيقها عند الضغط على الزر التنزيل يلي جنب اختر منتج

                    }
                    catch (Exception) { }


                }
            }
        }

        private void btnDeleteItems_Click(object sender, EventArgs e)
        {
            if (DgvSale.Rows.Count >= 1)
            {
                int index = DgvSale.SelectedRows[0].Index;
                DgvSale.Rows.RemoveAt(index);

                if (DgvSale.Rows.Count <= 0)
                {
                    txtTotal.Text = "0";
                }
                //لقد عدنا ووضعناه هنا من اجل عند المسح الصف يلي انا بدي ياه
                try
                {
                    //هنا منسوي اعادة حساب الاجمالي
                    decimal TotalOrder = 0;
                    for (int i = 0; i <= DgvSale.Rows.Count - 1; i++)
                    {
                        TotalOrder += Convert.ToDecimal(DgvSale.Rows[i].Cells[5].Value);
                        //هاد الكود رح يكون عند اضافة منتج الخط الاصفر رح يكون على الخانة المضافة جديدا
                        DgvSale.ClearSelection();
                        DgvSale.FirstDisplayedScrollingRowIndex = DgvSale.Rows.Count - 1;
                        DgvSale.Rows[DgvSale.Rows.Count - 1].Selected = true;

                    }
                    txtTotal.Text = Math.Round(TotalOrder, 2).ToString();
                    //هنا لقد جمعنا الاجمالي ووضعناه في اجمالي المطلوب وهذه ال ماث راوند من اجل وضع فاصلة والارقام التي بعد الفاصلة 2 فقط
                    lblItemscount.Text = (DgvSale.Rows.Count).ToString();
                    //هذه من اجل تعديل عدد الاصناف وطبعا كل هذه العمليات نحن نريد تحقيقها عند الضغط على الزر التنزيل يلي جنب اختر منتج

                }
                catch (Exception) { }
            }
        }

        //اسم على مسمة الحدث رح يصير لما يصير تغير في العواميد
        private void DgvSale_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            //هنا الحدث عندما يتم تغير في القيم العاميد تبع DgvBuy
            //واظهار الاجمالي بشكل صحيح
            decimal Item_Qty = 0, Item_SalePrice = 0, Item_Discount = 0;
            try
            {
                int index = DgvSale.SelectedRows[0].Index;

                Item_Qty = Convert.ToDecimal(DgvSale.Rows[index].Cells[2].Value);
                Item_SalePrice = Convert.ToDecimal(DgvSale.Rows[index].Cells[3].Value);
                Item_Discount = Convert.ToDecimal(DgvSale.Rows[index].Cells[4].Value);

                decimal Total = 0;
                Total = (Item_Qty * Item_SalePrice) - Item_Discount;

                DgvSale.Rows[index].Cells[5].Value = Total;

                //وهنا هاد الكود يحسب الاجمالي المطلوب عند تغير اي عدد في الخانات
                decimal TotalOrder = 0;
                for (int i = 0; i <= DgvSale.Rows.Count - 1; i++)
                {
                    TotalOrder += Convert.ToDecimal(DgvSale.Rows[i].Cells[5].Value);
                }
                txtTotal.Text = Math.Round(TotalOrder, 2).ToString();

            }
            catch (Exception) { }

        }
    }
}