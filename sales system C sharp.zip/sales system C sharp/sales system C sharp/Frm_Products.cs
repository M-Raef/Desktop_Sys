﻿using DevExpress.XtraEditors;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows;
using System.Xml.Linq;

namespace sales_system_C_sharp
{
    public partial class Frm_Products : DevExpress.XtraEditors.XtraForm
    {
        public Frm_Products()
        {
            InitializeComponent();
        }
        Database_class db = new Database_class();
        DataTable tbl = new DataTable();
        //هنا عند الضغط مرتين على ال فورم مشان الرقم التلقائي
        private void AutoNumber()
        {
            tbl.Clear();
            tbl = db.readData("select max (Pro_ID) from Products", "");

            if ((tbl.Rows[0][0].ToString() == DBNull.Value.ToString()))
            {
                txtID.Text = "1";
            }
            else
            {
                txtID.Text = (Convert.ToInt32(tbl.Rows[0][0]) + 1).ToString();
            }

            txtBarcode.Clear();
            txtProName.Clear();
            txtProNameSearch.Clear();
            NudBuyPrice.Value = 1;
            NudSalePrice.Value = 1;
            NudMinQty.Value = 0;
            NudMaxDiscount.Value = 0;
            NudQty.Value = 0;
            //هذه من اجل تفعيل الزر يسار زر البحث وتفعيلها عند ال اوتو نمبر
            try
            {
                FillPro();
                cbxProducts.SelectedIndex = 0;
            }
            catch(Exception) { }

            //هنا لقد قمنا بتصفير ةتنضيف القيم التابعة للخانات
            btnAdd.Enabled = true;
            btnNew.Enabled = true;
            btnDelete.Enabled = false;
            btnDeleteAll.Enabled = false;
            btnSave.Enabled = false;

        }


        int row;
        //الان هذه الدالة من اجل عرض البيانات
        private void show()
        {
            tbl.Clear();
            tbl = db.readData("select * from Products", "");

            if (tbl.Rows.Count <= 0)
            {
                MessageBox.Show("لا يوجد بيانات في هذه الشاشة");
            }
            else
            {
                try
                {
                    txtID.Text = tbl.Rows[row][0].ToString();
                    txtProName.Text =tbl.Rows[row][1].ToString();
                    NudQty.Value = Convert.ToDecimal( tbl.Rows[row][2]);
                    NudBuyPrice.Value = Convert.ToDecimal(tbl.Rows[row][3]);
                    NudSalePrice.Value = Convert.ToDecimal(tbl.Rows[row][4]);
                    txtBarcode.Text = tbl.Rows[row][5].ToString();
                    NudMinQty.Value = Convert.ToDecimal(tbl.Rows[row][6]);
                    NudMaxDiscount.Value = Convert.ToDecimal(tbl.Rows[row][7]);


                }
                catch (Exception) { }

            }
            btnAdd.Enabled = false;
            btnNew.Enabled = true;
            btnDelete.Enabled = true;
            btnDeleteAll.Enabled = true;
            btnSave.Enabled = true;
        }

        //هذه من اجل عرض المنتجات في 
        //cbxProducts
        //ولكن عند اضافة المنتج لم تظهر خصائصه معه هذه سوف نعملها لاحقا
        private void FillPro()
        {
            cbxProducts.DataSource = db.readData("select * from Products", "");
            cbxProducts.DisplayMember = "Pro_Name";
            cbxProducts.ValueMember = "Pro_ID";
        }

        private void Frm_Products_Load(object sender, EventArgs e)
        {
            try
            {
                AutoNumber();
            }
            catch(Exception) { }
        }

        private void btnFirst_Click(object sender, EventArgs e)
        {
            //برمجة سهم اقصى يسار
            row = 0;
            show();
        }

        private void btnPrev_Click(object sender, EventArgs e)
        {
            //برمجة سهم يسار
            if (row == 0)
            {
                tbl.Clear();
                tbl = db.readData(" select count(Pro_ID) from Products ", "");
                row = (Convert.ToInt32(tbl.Rows[0][0]) - 1);
                show();
            }
            else
            {
                row--;
                show();
            }
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            //برمجة سهم يمين
            tbl.Clear();
            tbl = db.readData(" select count(Pro_ID) from Products ", "");
            if (Convert.ToInt32(tbl.Rows[0][0]) - 1 == row)
            {
                row = 0;
                show();
            }
            else
            {
                row++;
                show();
            }
        }

        private void btnLast_Click(object sender, EventArgs e)
        {
            //برمجة سهم اقصى يمين

            tbl.Clear();
            tbl = db.readData(" select count(Pro_ID) from Products ", "");
            row = (Convert.ToInt32(tbl.Rows[0][0]) - 1);
            show();
        }

        private void btnNew_Click(object sender, EventArgs e)
        {
            //برمجة زر جديد
            AutoNumber();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        { 
            //برمجة زر اضافة
            //هنا لقد ضفنا بعض الخصائص
            if (txtProName.Text=="")
            {
                MessageBox.Show("من فضلك الرجاء ادخال اسم المنتج اولا !!", "تحذير");
                return;
            }
            if (NudBuyPrice.Value <=0)
            {
                MessageBox.Show("لا يمكن ادخال رقم الشراء اقل من 1 !!", "تحذير");
                return;
            }
            if (NudSalePrice.Value <=0)
            {
                MessageBox.Show("لا يمكن ادخال رقم البيع اقل من 1  !!", "تحذير");
                return;
            }
            if (NudMaxDiscount.Value >= NudSalePrice.Value )
            {
                MessageBox.Show("لا يمكن ان يكون الخصم المسموح اكبر من سعر البيع !!", "تحذير");
                return;
            }
            if (NudBuyPrice.Value>NudSalePrice.Value)
            {
                MessageBox.Show("لا يمكن ان يكون سعر الشراء اكبر من سعر البيع !!", "تحذير");
                return;
            }
            if (NudMinQty.Value>NudQty.Value)
            {
                MessageBox.Show(" لا يمكن ان يكون حد الطلب اكبر من الكمية الموجودة !!", "تحذير");
                return;
            }
            //هنا عند اضافة الاشياء يجب ان تكون في نفس ترتيب ال (س ك ل )و  
            db.exceuteData("insert into Products values (" + txtID.Text + ",N'"+txtProName.Text+"',"+NudQty.Value+","+NudBuyPrice.Value+","+NudSalePrice.Value+",N'"+txtBarcode.Text+"',"+NudMinQty.Value+","+NudMaxDiscount.Value+" )", "تم الاضافة بنجاح");

            AutoNumber();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            //برمجة زر اضافة
            //هنا لقد ضفنا بعض الخصائص
            if (txtProName.Text == "")
            {
                MessageBox.Show("من فضلك الرجاء ادخال اسم المنتج اولا !!", "تحذير");
                return;
            }
            if (NudBuyPrice.Value <= 0)
            {
                MessageBox.Show("لا يمكن ادخال رقم الشراء اقل من 1 !!", "تحذير");
                return;
            }
            if (NudSalePrice.Value <= 0)
            {
                MessageBox.Show("لا يمكن ادخال رقم البيع اقل من 1  !!", "تحذير");
                return;
            }
            if (NudMaxDiscount.Value >= NudSalePrice.Value)
            {
                MessageBox.Show("لا يمكن ان يكون الخصم المسموح اكبر من سعر البيع !!", "تحذير");
                return;
            }
            if (NudBuyPrice.Value > NudSalePrice.Value)
            {
                MessageBox.Show("لا يمكن ان يكون سعر الشراء اكبر من سعر البيع !!", "تحذير");
                return;
            }
            if (NudMinQty.Value > NudQty.Value)
            {
                MessageBox.Show(" لا يمكن ان يكون حد الطلب اكبر من الكمية الموجودة !!", "تحذير");
                return;
            }
            //هنا عند اضافة الاشياء يجب ان تكون في نفس ترتيب ال (س ك ل )و  
            db.exceuteData("update Products set Pro_Name=N'" + txtProName.Text + "',Qty=" + NudQty.Value + ",Buy_Price=" + NudBuyPrice.Value + ",Sale_Price=" + NudSalePrice.Value + ",Barcode=N'" + txtBarcode.Text + "',MinQty=" + NudMinQty.Value + ",MaxDiscount=" + NudMaxDiscount.Value + " where Pro_ID="+txtID.Text+" ", "تم التعديل بنجاح");

            AutoNumber();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("هل انت متأكد من مسح البيانات", "تحذير!!!", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
            {
                db.readData("delete from Products where Pro_ID = " + txtID.Text + "", "تم مسح بيانات بنجاح");
                AutoNumber();
            }
        }

        private void btnDeleteAll_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("هل انت متأكد من مسح البيانات", "تحذير!!!", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
            {
                db.readData("delete from Products", "تم مسح بيانات بنجاح");
                AutoNumber();
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            if(txtProNameSearch.Text != "")
            {
                DataTable tblSearch = new DataTable();
                tblSearch.Clear();

                tblSearch = db.readData("select * from Products where Pro_Name Like N'%"+txtProNameSearch.Text+"%' ", "");
                //من اجل ادخال حرف شبيه ان يظهر كلمة يوجد الحرف الذي سوف ادخله واشارة %من اجل اذا كان الحرف في بداية او نهاية الكلمة
                if (tblSearch.Rows.Count <= 0)
                {
                    MessageBox.Show("لا يوجد بهذا الاسم");
                }
                else
                {
                    try
                    {
                        //وهنا سبب كتابة 0 محل ال رو من اجل عند البحث الكلمة التي تتواجد داخل اول عامود ان ياتي بها
                        txtID.Text = tblSearch.Rows[0][0].ToString();
                        txtProName.Text = tblSearch.Rows[0][1].ToString();
                        NudQty.Value = Convert.ToDecimal(tblSearch.Rows[0][2]);
                        NudBuyPrice.Value = Convert.ToDecimal(tblSearch.Rows[0][3]);
                        NudSalePrice.Value = Convert.ToDecimal(tblSearch.Rows[0][4]);
                        txtBarcode.Text = tblSearch.Rows[row][5].ToString();
                        NudMinQty.Value = Convert.ToDecimal(tblSearch.Rows[0][6]);
                        NudMaxDiscount.Value = Convert.ToDecimal(tblSearch.Rows[0][7]);


                    }
                    catch (Exception) { }

                }
                btnAdd.Enabled = false;
                btnNew.Enabled = true;
                btnDelete.Enabled = true;
                btnDeleteAll.Enabled = true;
                btnSave.Enabled = true;
            }
        }

        //هذا الحدث هو عند اختيار اي من الخانات المجودة داخل الشريط يسار زر البحث
        private void cbxProducts_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void cbxProducts_SelectionChangeCommitted(object sender, EventArgs e)
        {
            if (cbxProducts.Items.Count >= 1)
            {
                DataTable tblSearch = new DataTable();
                tblSearch.Clear();

                //وهذه ال الحالة الشرطية من اجل عدم اظهار خطا عند تشغيله اول مرة وهو المشكل انه الحدث يلي انا فيه الان بيبلش يتنفذ قبل ما البيانات تحمل
               
                tblSearch = db.readData("select * from Products where Pro_ID = " + cbxProducts.SelectedValue + " ", "");

                if (tblSearch.Rows.Count <= 0)
                {

                }
                else
                {
                    try
                    {
                        //وهنا سبب كتابة 0 محل ال رو من اجل عند البحث الكلمة التي تتواجد داخل اول عامود ان ياتي بها
                        txtID.Text = tblSearch.Rows[0][0].ToString();
                        txtProName.Text = tblSearch.Rows[0][1].ToString();
                        NudQty.Value = Convert.ToDecimal(tblSearch.Rows[0][2]);
                        NudBuyPrice.Value = Convert.ToDecimal(tblSearch.Rows[0][3]);
                        NudSalePrice.Value = Convert.ToDecimal(tblSearch.Rows[0][4]);
                        txtBarcode.Text = tblSearch.Rows[row][5].ToString();
                        NudMinQty.Value = Convert.ToDecimal(tblSearch.Rows[0][6]);
                        NudMaxDiscount.Value = Convert.ToDecimal(tblSearch.Rows[0][7]);


                    }
                    catch (Exception) { }

                }
                btnAdd.Enabled = false;
                btnNew.Enabled = true;
                btnDelete.Enabled = true;
                btnDeleteAll.Enabled = true;
                btnSave.Enabled = true;
                


            }
        }
    }
}