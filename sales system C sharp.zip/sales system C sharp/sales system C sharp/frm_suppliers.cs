﻿using DevExpress.XtraEditors;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sales_system_C_sharp
{
    public partial class frm_suppliers : DevExpress.XtraEditors.XtraForm
    {
        public frm_suppliers()
        {
            InitializeComponent();
        }

        Database_class db = new Database_class();
        DataTable tbl = new DataTable();
        //هنا عند الضغط مرتين على ال فورم مشان الرقم التلقائي
        private void AutoNumber()
        {
            tbl.Clear();
            tbl = db.readData("select max (Sup_ID) from Suppliers", "");

            if ((tbl.Rows[0][0].ToString() == DBNull.Value.ToString()))
            {
                txtID.Text = "1";
            }
            else
            {
                txtID.Text = (Convert.ToInt32(tbl.Rows[0][0]) + 1).ToString();
            }

            txtName.Clear();
            txtPhone.Clear();
            txtAddress.Clear();
            txtNotes.Clear();
            txtSearch.Clear();

            btnAdd.Enabled = true;
            btnNew.Enabled = true;
            btnDelete.Enabled = false;
            btnDeleteAll.Enabled = false;
            btnSave.Enabled = false;

        }


        int row;
        //الان هذه الدالة من اجل عرض البيانات
        private void show()
        {
            tbl.Clear();
            tbl = db.readData("select * from Suppliers", "");

            if (tbl.Rows.Count <= 0)
            {
                MessageBox.Show("لا يوجد بيانات في هذه الشاشة");
            }
            else
            {
                txtID.Text = tbl.Rows[row][0].ToString();
                txtName.Text = tbl.Rows[row][1].ToString();
                txtPhone.Text = tbl.Rows[row][2].ToString();
                txtAddress.Text = tbl.Rows[row][3].ToString();
                txtNotes.Text = tbl.Rows[row][4].ToString();
            }
            btnAdd.Enabled = false;
            btnNew.Enabled = true;
            btnDelete.Enabled = true;
            btnDeleteAll.Enabled = true;
            btnSave.Enabled = true;
        }


        private void frm_suppliers_Load(object sender, EventArgs e)
        {
            AutoNumber(); 
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (txtName.Text == "")
            {
                MessageBox.Show("من فضلك الرجاء ادخال المورد!!", "تحذير");
                return;
            }
            db.exceuteData("insert into Suppliers values (" + txtID.Text + ",'" + txtName.Text + "', '" + txtAddress.Text + "', '" + txtPhone.Text + "', '" + txtNotes.Text + "' )", "تم الاضافة بنجاح");
            AutoNumber();
        }

        private void btnLast_Click(object sender, EventArgs e)
        {
            tbl.Clear();
            tbl = db.readData(" select count(Sup_ID) from Suppliers ", "");
            row = (Convert.ToInt32(tbl.Rows[0][0]) - 1);
            show();
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            tbl.Clear();
            tbl = db.readData(" select count(Sup_ID) from Suppliers ", "");
            if (Convert.ToInt32(tbl.Rows[0][0]) - 1 == row)
            {
                row = 0;
                show();
            }
            else
            {
                row++;
                show();
            }
        }

        private void btnPrev_Click(object sender, EventArgs e)
        {

            if (row == 0)
            {
                tbl.Clear();
                tbl = db.readData(" select count(Sup_ID) from Suppliers ", "");
                row = (Convert.ToInt32(tbl.Rows[0][0]) - 1);
                show();
            }
            else
            {
                row--;
                show();
            }
        }

        private void btnFirst_Click(object sender, EventArgs e)
        {
            row = 0;
            show();
        }

        private void btnNew_Click(object sender, EventArgs e)
        {
            AutoNumber();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            db.readData("update Suppliers set Sup_Name = N'" + txtName.Text + "', Sup_Phone = N'" + txtPhone.Text + "', Sup_Address = N'" + txtAddress.Text + "',Notes = N'" + txtNotes.Text + "' where Sup_ID = " + txtID.Text + " ", "تم تعديل البيانات بنجاح");
            AutoNumber();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("هل انت متأكد من مسح البيانات", "تحذير!!!", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
            {
                db.readData("delete from Suppliers where Sup_ID = " + txtID.Text + "", "تم مسح بيانات المورد بنجاح");
                AutoNumber();
            }
        }

        private void btnDeleteAll_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("هل انت متأكد من مسح البيانات", "تحذير!!!", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
            {
                db.readData("delete from Suppliers ", "تم مسح  جميع بيانات الموردين بنجاح");
                AutoNumber();
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
          // DataTable tblSearch = new DataTable(); 

            tbl.Clear();  //tbl بصير اني اعمل هيك وضيف تحت بس 
            tbl = db.readData("select * from Suppliers where Sup_Name like N'%" + txtSearch.Text + "%' ", "");

            //هنا في السشرتش ما عم يظبط ولا اعرف السبب لاكن عند المعلم ذبضت
            //tblSearch.Clear();
            //tblSearch = db.readData("select * from Suppliers where Sup_Name like N'%" + txtSearch.Text + "%' ", "");

            try
            {
                txtID.Text = tbl.Rows[0][0].ToString();
                txtName.Text = tbl.Rows[0][1].ToString();
                txtAddress.Text = tbl.Rows[0][2].ToString();
                txtPhone.Text = tbl.Rows[0][3].ToString();
                txtNotes.Text = tbl.Rows[0][4].ToString();
            }
            catch (Exception)
            {

            }
            btnAdd.Enabled = false;
            btnNew.Enabled = true;
            btnDelete.Enabled = true;
            btnDeleteAll.Enabled = true;
            btnSave.Enabled = true;
        }

        private void frm_suppliers_FormClosing(object sender, FormClosingEventArgs e)
        {
            //هذه من اجل عند شاشة المشتريات عند ثلاث نقاط عند فتح المورد وادخال قيم وعند تسكريه انه ينقل البيانات بدون ما احتاج اني اقفل البرنامج وارجع شغله
            try
            {
                frm_Buy.GetFormBuy.FillSupplier();
            }catch(Exception) { }
        }
    }
    
}