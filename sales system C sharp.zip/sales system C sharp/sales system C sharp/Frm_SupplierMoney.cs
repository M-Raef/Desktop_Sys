﻿using DevExpress.XtraEditors;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sales_system_C_sharp
{
    public partial class Frm_SupplierMoney : DevExpress.XtraEditors.XtraForm
    {
        public Frm_SupplierMoney()
        {
            InitializeComponent();
        }
        Database_class db = new Database_class();
        DataTable tbl = new DataTable();

        //هذا الكود من اجل ملئ بيانات الشاشة عند اختيار الموردين
        private void FillSupplier()
        {
            cbxSupplier.DataSource = db.readData("select * from Suppliers", "");
            cbxSupplier.DisplayMember= "Sup_Name";
            cbxSupplier.ValueMember= "Sup_ID";
        }
        private void Frm_SupplierMoney_Load(object sender, EventArgs e)
        {
            try
            {
                FillSupplier();
            }
            catch (Exception) { }

            DtpDate.Text = DateTime.Now.ToShortDateString();

            tbl.Clear();
            tbl = db.readData("SELECT [Order_ID] as 'رقم الفاتورة',Suppliers.Sup_Name as 'اسم المورد',[Price] as 'السعر',[Order_Date] as 'تاريخ الفاتورة',[Reminder_Date] as 'تاريخ الاستحقاق'FROM [dbo].[Supplier_Money],Suppliers where Suppliers.Sup_ID = [Supplier_Money].Sup_ID", "");
            //هنا لقد نادينا المعلومات ووضعنا اسم المورد الذي نريده ان يظهر مقابل رقمه ولقد وضعناها داخل الشاشة البيضاء
            DgvSearch.DataSource= tbl;

            //اما هذا الكود من اجل جمع المبالغ ووضعه داخل اجمالي المبالغ
            decimal totalPrice = 0;
            for(int i =0; i<= DgvSearch.Rows.Count -1; i++)
            {
                totalPrice += Convert.ToDecimal(DgvSearch.Rows[i].Cells[2].Value);
            }
            txtTotal.Text = Math.Round(totalPrice, 2).ToString();

        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            // وهذا ايضا كود بحث ولكن رج يكون عندما احدد كل الموردين او مورد انا اريده
            tbl.Clear();

            if(rbtnAllSup.Checked == true)
            {
                tbl = db.readData("SELECT [Order_ID] as 'رقم الفاتورة',Suppliers.Sup_Name as 'اسم المورد',[Price] as 'السعر',[Order_Date] as 'تاريخ الفاتورة',[Reminder_Date] as 'تاريخ الاستحقاق'FROM [dbo].[Supplier_Money],Suppliers where Suppliers.Sup_ID = [Supplier_Money].Sup_ID", "");
            }
            else if(rbtnOneSup .Checked == true)
            {
                tbl = db.readData("SELECT [Order_ID] as 'رقم الفاتورة',Suppliers.Sup_Name as 'اسم المورد',[Price] as 'السعر',[Order_Date] as 'تاريخ الفاتورة',[Reminder_Date] as 'تاريخ الاستحقاق'FROM [dbo].[Supplier_Money],Suppliers where Suppliers.Sup_ID = [Supplier_Money].Sup_ID and Suppliers.Sup_ID="+cbxSupplier.SelectedValue+"", "");
            }

            DgvSearch.DataSource = tbl;

            decimal totalPrice = 0;
            for (int i = 0; i <= DgvSearch.Rows.Count - 1; i++)
            {
                totalPrice += Convert.ToDecimal(DgvSearch.Rows[i].Cells[2].Value);
            }
            txtTotal.Text = Math.Round(totalPrice, 2).ToString();

        }

        private void btnPay_Click(object sender, EventArgs e)
        {
            if(DgvSearch.Rows.Count >= 1)
            {
                string d = DtpDate.Value.ToString("dd/MM/yyyy");
                if (rbtnPayAll.Checked == true)
                {
                    if (MessageBox.Show("هل انت متأكد من تسديد المبلغ", "تحذير!!!", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                    {
                        //هذا الكود بعد التحقق من الشروط بعد تسديد جميع المبالغ رح يمسح المعلومات الخاصة بالدين ورح يحفظها داخل البيانات المسددة
                        if(rbtnAllSup.Checked == true) { MessageBox.Show("من فضلك حدد اسم مورد", "تاكيد"); return; }
                        db.exceuteData("delete from Supplier_Money where Order_ID=" + DgvSearch.CurrentRow.Cells[0].Value + " and Price =" + DgvSearch.CurrentRow.Cells[2].Value + " ", "");
                        db.exceuteData("insert into Supplier_Report values ("+ DgvSearch.CurrentRow.Cells[0].Value + ","+ DgvSearch.CurrentRow.Cells[2].Value + ", '"+d+"', "+cbxSupplier.SelectedValue+") ", "تم تسديد المبلغ بنجاح");

                        Frm_SupplierMoney_Load(null,null);
                    }
                }
                else if(rbtnPayPart.Checked == true)
                {
                    if (MessageBox.Show("هل انت متأكد من تسديد المبلغ", "تحذير!!!", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                    {
                        //هذا الكود بعد التحقق من الشروط بعد تسديد جميع المبالغ رح يمسح المعلومات الخاصة بالدين ورح يحفظها داخل البيانات المسددة
                        if (rbtnAllSup.Checked == true) { MessageBox.Show("من فضلك حدد اسم مورد", "تاكيد"); return; }
                        
                        decimal money = Convert.ToDecimal( DgvSearch.CurrentRow.Cells[2].Value) - NudPrice.Value;
                        //بهذا السطر يلي تحت رح يعدل سعر الاجمالي من يلي كان عليه رح ينقص يلي ح يندفع 
                        db.exceuteData("update Supplier_Money set Price = "+money+" where Order_ID=" + DgvSearch.CurrentRow.Cells[0].Value  +" and price=" + DgvSearch.CurrentRow.Cells[2].Value +" ", "");
                        db.exceuteData("insert into Supplier_Report values (" + DgvSearch.CurrentRow.Cells[0].Value + "," + NudPrice.Value + ", '" + d + "', " + cbxSupplier.SelectedValue + ") ", "تم تسديد المبلغ بنجاح");

                        Frm_SupplierMoney_Load(null, null);
                    }
                }
            }
        }

        private void PrintOneSupplier()
        {
            int id = Convert.ToInt32(cbxSupplier.SelectedValue);

            DataTable tblRpt = new DataTable();

            tblRpt.Clear();
            //هذه من اجل قراءة المعلومات الموجودة لازم تكون نفسها يلي استخدمناها داخل مكان عمل الفاتورة
            tblRpt = db.readData("SELECT [Order_ID] as 'رقم الفاتورة', Suppliers.Sup_ID as'رقم المورد' ,Suppliers.Sup_Name as 'اسم المورد',[Price] as 'السعر',[Order_Date] as 'تاريخ الفاتورة',[Reminder_Date] as 'تاريخ الاستحقاق'FROM [dbo].[Supplier_Money],Suppliers where Suppliers.Sup_ID = [Supplier_Money].Sup_ID ", "");

            try
            {
                Frm_Printing frm = new Frm_Printing();

                RptSupplierMoney rpt = new RptSupplierMoney();


                //هذه الدالة من اجل عمل رفرش للصفحة من اجل اعادة تحميل البيانات فيها لان رح نستخدمها اكتر من مرة
                //وهنا من اجل عرض هذه crystalReportViewer2 => modifires => public
                frm.crystalReportViewer2.RefreshReport();

                //هذه الدالة مهمة جدا من اجل عند فتح الفاتورة عند جهاز العميل سوف تظهر مشكلة ويلي هي قاعدة البيانات رح يطلب اسم المستخدم وكلمة السر ولو دخلتهم ما رح يمشي الحال من اجل حل المشكلة رح نعمل هيك كود رح يطلب 4 متغيرات اسم المستخدم تبعت قاعدة البيانات واسم المستخدم تبعت قاعدة البيانات واسم اسيرفر تبعيواسم قاعدةالبيانات تبعتي
                rpt.SetDatabaseLogon("", "", "LAPTOP-ITEHASQ2", "Sales_System");
                rpt.SetDataSource(tblRpt);
                //لقد قمنا هنا ب عمل اد بطريقة parameter fields => new => name = id 
                //ولقد سويناه لرقم الفاتورة ليتزامنو وذهبنا الى خصائصه بعد ما وجدناه وجعلناه يساويرقم ال اد للفاتورة من اجل ان يتغير عند عمل كل فاتورة وممكن ان اغير بخصائص ال اد للشكل الذي اريده
                rpt.SetParameterValue("ID", id);
                //هاد الكود من اجل ان يظهر الفاتورة يلي صممناها داخل ال frm_printing
                frm.crystalReportViewer2.ReportSource = rpt;


                //هذا الكود من اجل طباعة الفاتورة في الجهاز ونقله الى pdf
                System.Drawing.Printing.PrintDocument printDocument = new System.Drawing.Printing.PrintDocument();
                rpt.PrintOptions.PrinterName = printDocument.PrinterSettings.PrinterName;
                //من اجل الطياعة المباشرة بدها اربع برميتري الاول كم عدد النسخ ولازم ترو وصفحة البداي والصفحة النهاية رح يكونو صفر بعدين رح نتعمق فيهم اكتر
                //rpt.PrintToPrinter(1, true, 0, 0);

                frm.ShowDialog();

            }
            catch (Exception ) { }
            
        }
        private void simpleButton1_Click(object sender, EventArgs e)
        {
            //if(rbtnOneSup.Checked == true)
            //{
            if(DgvSearch.Rows.Count >= 1)
            {
                PrintOneSupplier();
            }
            
        }
    }
}