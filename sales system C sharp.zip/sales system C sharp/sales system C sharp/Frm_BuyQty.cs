﻿using DevExpress.XtraEditors;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sales_system_C_sharp
{
    public partial class Frm_BuyQty : DevExpress.XtraEditors.XtraForm
    {
        public Frm_BuyQty()
        {
            InitializeComponent();
        }

        private void Frm_BuyQty_Load(object sender, EventArgs e)
        {
            //هنا من اجل وضع المعلومات التي سوف نوصلها بلمعلومات بالشاشة
            //هنا حولنا من خلال تو سترنغ ممكن من بداية نحولها من خلال كونفيرت
            txtQty.Text = (Properties.Settings.Default.Item_Qty).ToString();
            txtBuyPrice.Text = (Properties.Settings.Default.Item_BuyPrice).ToString();
            txtDiscount.Text = (Properties.Settings.Default.Item_Discount).ToString();

            txtQty.Focus();
        }

        private void btnEnter_Click(object sender, EventArgs e)
        {
            //هذول الثلاث الشروط رح نتاكد انه ما يرجعلنا القيم الثلاثة فاضية
            if(txtQty.Text == "")
            {
                MessageBox.Show("من فضلك ادخل الكمية", "تاكيد");
                return;
            }
            if (txtBuyPrice.Text == "")
            {
                MessageBox.Show("من فضلك ادخل سعر الشراء", "تاكيد");
                return;
            }
            if (txtDiscount.Text == "")
            {
                MessageBox.Show("من فضلك ادخل الخصم", "تاكيد");
                return;
            }
            //بهذه الطريقة حطينا القمفي شاشاة باي كتواي واخر الشي لازم الحفظ و الاقفال
            Properties.Settings.Default.Item_Qty = Convert.ToDecimal(txtQty.Text); 
            Properties.Settings.Default.Item_Discount = Convert.ToDecimal(txtDiscount.Text);
            Properties.Settings.Default.Item_BuyPrice = Convert.ToDecimal(txtBuyPrice.Text);
            Properties.Settings.Default.Save();
            Close();
        }

        private void Frm_BuyQty_KeyDown(object sender, KeyEventArgs e)
        {
            if(e.KeyCode == Keys.Enter)
            {
                // هذول الثلاث الشروط رح نتاكد انه ما يرجعلنا القيم الثلاثة فاضية
            if (txtQty.Text == "")
                {
                    MessageBox.Show("من فضلك ادخل الكمية", "تاكيد");
                    return;
                }
                if (txtBuyPrice.Text == "")
                {
                    MessageBox.Show("من فضلك ادخل سعر الشراء", "تاكيد");
                    return;
                }
                if (txtDiscount.Text == "")
                {
                    MessageBox.Show("من فضلك ادخل الخصم", "تاكيد");
                    return;
                }
                //بهذه الطريقة حطينا القمفي شاشاة باي كتواي واخر الشي لازم الحفظ و الاقفال
                Properties.Settings.Default.Item_Qty = Convert.ToDecimal(txtQty.Text);
                Properties.Settings.Default.Item_Discount = Convert.ToDecimal(txtDiscount.Text);
                Properties.Settings.Default.Item_BuyPrice = Convert.ToDecimal(txtBuyPrice.Text);
                Properties.Settings.Default.Save();
                Close();
            }
        }

        private void Frm_BuyQty_FormClosed(object sender, FormClosedEventArgs e)
        {
           

        }

        private void Frm_BuyQty_FormClosing(object sender, FormClosingEventArgs e)
        {
            //من اجل نقل المعلومات بعد تغيرها الى DgvBuy 
            //ورح يتم نقل المعلومات بعد تسكيرها

            try
            {
                int index = frm_Buy.GetFormBuy.DgvBuy.SelectedRows[0].Index;

                frm_Buy.GetFormBuy.DgvBuy.Rows[index].Cells[2].Value = Properties.Settings.Default.Item_Qty;
                frm_Buy.GetFormBuy.DgvBuy.Rows[index].Cells[3].Value = Properties.Settings.Default.Item_BuyPrice;
                frm_Buy.GetFormBuy.DgvBuy.Rows[index].Cells[4].Value = Properties.Settings.Default.Item_Discount;


            }
            catch (Exception) { }
        }
    }
}