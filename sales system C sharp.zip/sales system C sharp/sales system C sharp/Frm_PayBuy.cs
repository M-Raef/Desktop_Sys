﻿using DevExpress.XtraEditors;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sales_system_C_sharp
{
    public partial class Frm_PayBuy : DevExpress.XtraEditors.XtraForm
    {
        public Frm_PayBuy()
        {
            InitializeComponent();
        }

        private void Frm_PayBuy_Load(object sender, EventArgs e)
        {
            try
            {
                txtMatloub.Text = (Properties.Settings.Default.TotalOrder).ToString();

            }catch(Exception ) { }

            txtMadfou3.Text = "0.0";
            txtBakey.Text = "0.0";
            txtMadfou3.Focus();
        }

        private void txtMadfou3_TextChanged(object sender, EventArgs e)
        {
            //هنا الحدث رح يتنفذ بخلال اعمل اي تغير للمدفوع
            //وهنا عملنا كود في حالة اضافة المدفوع رح يعطيني الباقي
            try
            {
                decimal baky = Convert.ToDecimal( txtMatloub.Text) - Convert.ToDecimal(txtMadfou3.Text);
                txtBakey.Text =Math.Round( baky,2).ToString();

            }catch(Exception ) { }
        }

        //هذا الكود من اجل الضغط على زر انتر
        private void btnEnter_Click(object sender, EventArgs e)
        {
            //هلق رح ناخد القيم يلي تم ادخالها وتخزينها في متغيرات يلي انا عملتها في الخصائص الرئيسية
            if (txtMadfou3.Text == "")
            {
                MessageBox.Show("من فضلك ادخل المبلغ المدفوع", "تاكيد");
                return;
            }
            Properties.Settings.Default.Madfou3 = Convert.ToDecimal(txtMadfou3.Text);
            Properties.Settings.Default.Bakey = Convert.ToDecimal(txtBakey.Text);

            //هذا الكود رح يكون لما اسوي انتر يعملي قيمت الزر ترو من اجل الحفظ والانتقال الى الفاتورة الثانية
            Properties.Settings.Default.CheckButton= true;

            Properties.Settings.Default.Save();
            Close();
        }

        //هذا الكود من اجل الضغط على اي زر
        private void Frm_PayBuy_KeyDown(object sender, KeyEventArgs e)
        {
            if(e.KeyCode == Keys.Enter)
            {
                if (txtMadfou3.Text == "")
                {
                    MessageBox.Show("من فضلك ادخل المبلغ المدفوع", "تاكيد");
                    return;
                }
                Properties.Settings.Default.Madfou3 = Convert.ToDecimal(txtMadfou3.Text);
                Properties.Settings.Default.Bakey = Convert.ToDecimal(txtBakey.Text);

                //هذا الكود رح يكون لما اسوي انتر يعملي قيمت الزر ترو من اجل الحفظ والانتقال الى الفاتورة الثانية
                Properties.Settings.Default.CheckButton = true;


                Properties.Settings.Default.Save();
                Close();
            }
            else if(e.KeyCode == Keys.F12)
            {
                Properties.Settings.Default.CheckButton = false;
                Properties.Settings.Default.Save();
                Close();
            }
        }

        private void btnReturn_Click(object sender, EventArgs e)
        {
            Properties.Settings.Default.CheckButton =false;
            Properties.Settings.Default.Save();

            //في المستقبل رح نعدل على هذا الكود
            Close();
        }
    }
}