﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using System.Windows.Forms;

namespace sales_system_C_sharp
{
    internal class Database_class
    {
        SqlConnection conn = new SqlConnection(@"Data Source=LAPTOP-ITEHASQ2;Initial Catalog=Sales_System;Integrated Security=True");
        SqlCommand cmd = new SqlCommand();

        //select
        public DataTable readData (string stmt, string message)
        {
            DataTable tbl = new DataTable();
            try
            {
                //connection to the database
                cmd.Connection = conn;
                cmd.CommandText = stmt;
                conn.Open();

                //load data fromdatabase to tbl
                tbl.Load(cmd.ExecuteReader());

                conn.Close();
                if (message != "")
                {
                    MessageBox.Show(message, "تاكيد", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conn.Close();
            }
            return tbl;
        }

        //insert delete update
        public bool exceuteData(string stmt, string message)

        {
            try
            {
                cmd.Connection = conn;
                cmd.CommandText = stmt;
                conn.Open();

                cmd.ExecuteNonQuery();

                conn.Close ();

                if(message != "")
                {
                    MessageBox.Show(message, "تاكيد", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

                return true;
            }catch (Exception ex)
            {
                return false;
            }
            finally
            {
                conn.Close();
            }
        }

    }
}
