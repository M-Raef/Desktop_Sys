﻿using DevExpress.XtraEditors;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sales_system_C_sharp
{
    public partial class frm_customers : DevExpress.XtraEditors.XtraForm
    {
        public frm_customers()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }


       
        Database_class db = new Database_class();
        DataTable tbl = new DataTable();
        //هنا عند الضغط مرتين على ال فورم مشان الرقم التلقائي
        private void AutoNumber()
        {
            tbl.Clear();
            tbl = db.readData("select max (Cust_ID) from Customers","");

            if ((tbl.Rows[0][0].ToString() == DBNull.Value.ToString()))
            {
                txtID.Text = "1";
            }
            else
            {
                txtID.Text = (Convert.ToInt32(tbl.Rows[0][0]) + 1).ToString();
            }

            txtName.Clear();
            txtPhone.Clear();
            txtAddress.Clear();
            txtNotes.Clear();
            txtSearch.Clear();

            btnAdd.Enabled = true;
            btnNew.Enabled = true;
            btnDelete.Enabled = false;
            btnDeleteAll.Enabled = false;
            btnSave.Enabled = false;

        }


        int row;
        //الان هذه الدالة من اجل عرض البيانات
        private void show()
        {
            tbl.Clear();
            tbl = db.readData("select * from Customers", "");

            if(tbl.Rows.Count <= 0)
            {
                MessageBox.Show("لا يوجد بيانات في هذه الشاشة");
            }
            else
            {
                txtID.Text = tbl.Rows[row][0].ToString();
                txtName.Text = tbl.Rows[row][1].ToString();
                txtPhone.Text = tbl.Rows[row][2].ToString();
                txtAddress.Text = tbl.Rows[row][3].ToString();
                txtNotes.Text = tbl.Rows[row][4].ToString();
            }
            btnAdd.Enabled =false;
            btnNew.Enabled =true;
            btnDelete.Enabled = true;
            btnDeleteAll.Enabled = true;
            btnSave.Enabled = true;
        }


        private void frm_customers_Load(object sender, EventArgs e)
        {
            AutoNumber();  
        }

        //من اجل زر اضافة البيانات
        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (txtName.Text =="")
            {
                MessageBox.Show("من فضلك الرجاء ادخال العميل!!","تحذير");
                return;
            }
            db.exceuteData("insert into Customers values (" + txtID.Text + ",'" + txtName.Text + "', '" + txtAddress.Text + "', '" + txtPhone.Text + "', '" + txtNotes.Text + "' )", "تم الاضافة بنجاح");
            AutoNumber(); 
        }

        //من اجل زر جديد
        private void btnNew_Click(object sender, EventArgs e)
        {
            AutoNumber();
        }

        //من اجل زر اقصى يسار
        private void btnFirst_Click(object sender, EventArgs e)
        {
            row = 0;
            show();
        }

        //زر الحفظ
        private void btnSave_Click(object sender, EventArgs e)
        {
            db.readData("update Customers set Cust_Name = N'" + txtName.Text + "',  Cust_Phone = N'" + txtPhone.Text+ "',Cust_Address = N'" + txtAddress.Text + "',Notes = N'" + txtNotes.Text+ "' where Cust_ID = "+txtID.Text+" ", "تم تعديل البيانات بنجاح");
            AutoNumber();
        }

        //زر المسح
        private void btnDelete_Click(object sender, EventArgs e)
        {
            if(MessageBox.Show("هل انت متأكد من مسح البانات","تحذير!!!",MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
            {
                db.readData("delete from Customers where Cust_ID = "+txtID.Text+"", "تم مسح بيانات العميل بنجاح");
                AutoNumber();
            }
        }

        //زر مسح الكل
        private void btnDeleteAll_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("هل انت متأكد من مسح البيانات", "تحذير!!!", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
            {
                db.readData("delete from Customers ", "تم مسح  جميع بيانات العميلاء  بنجاح");
                AutoNumber();
            }
        }

        //من اجل اقصى يمين
        private void btnLast_Click(object sender, EventArgs e)
        {
            tbl.Clear();
            tbl = db.readData(" select count(Cust_ID) from Customers ", "");
            row = (Convert.ToInt32(tbl.Rows[0][0]) -1);
            show();
        }

        //من اجل زر اليمين
        private void btnNext_Click(object sender, EventArgs e)
        {
            tbl.Clear();
            tbl = db.readData(" select count(Cust_ID) from Customers ", "");
            if (Convert.ToInt32(tbl.Rows[0][0]) - 1 == row)
            {
                row = 0;
                show();
            }
            else
            {
                row++;
                show();
            }
            
        }

        //من اجل زر اليسار
        private void btnPrev_Click(object sender, EventArgs e)
        {
            if (row==0)
            {
                tbl.Clear();
                tbl = db.readData(" select count(Cust_ID) from Customers ", "");
                row = (Convert.ToInt32(tbl.Rows[0][0]) - 1);
                show();
            }
            else
            {
                row--;
                show();
            }
            
        }

        //زر البحث
        private void btnSearch_Click(object sender, EventArgs e)
        {
            //DataTable tblSearch = new DataTable(); 

            tbl.Clear();  //tbl بصير اني اعمل هيك وضيف تحت بس 
            tbl = db.readData("select * from Customers where Cust_Name like N'%" + txtSearch.Text + "%' ", "");

            //هنا في السشرتش ما عم يظبط ولا اعرف السبب لاكن عند المعلم ذبضت
            //tblSearch.Clear();
            //tblSearch = db.readData("select * from Customers where Cust_Name like N'%" + txtSearch.Text + "%' ", "");

            try
            {
                txtID.Text = tbl.Rows[0][0].ToString();
                txtName.Text = tbl.Rows[0][1].ToString();
                txtAddress.Text = tbl.Rows[0][2].ToString();
                txtPhone.Text = tbl.Rows[0][3].ToString();
                txtNotes.Text = tbl.Rows[0][4].ToString();
            }
            catch (Exception)
            {

            }
            btnAdd.Enabled = false;
            btnNew.Enabled = true;
            btnDelete.Enabled = true;
            btnDeleteAll.Enabled = true;
            btnSave.Enabled = true;
        }

        private void frm_customers_FormClosing(object sender, FormClosingEventArgs e)
        {
            //هنا نحن رح ننادي هي الصفحة في شاشة البيعات فبعد تسكير الصفحة ابيه يملئلي البيانات
            try
            {
                Frm_Sales.GetFormSales.FillCustomer();

            }catch (Exception ) { }
        }
    }
}