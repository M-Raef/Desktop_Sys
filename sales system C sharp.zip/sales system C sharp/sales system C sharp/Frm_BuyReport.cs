﻿using DevExpress.XtraEditors;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sales_system_C_sharp
{
    public partial class Frm_BuyReport : DevExpress.XtraEditors.XtraForm
    {
        public Frm_BuyReport()
        {
            InitializeComponent();
        }

        Database_class db = new Database_class();
        DataTable tbl = new DataTable();

        private void FillSupplier()
        {
            cbxSupplier.DataSource = db.readData("select * from Suppliers", "");
            cbxSupplier.DisplayMember = "Sup_Name";
            cbxSupplier.ValueMember = "Sup_ID";
        }

        private void Frm_BuyReport_Load(object sender, EventArgs e)
        {
            FillSupplier();
            DtpFrom.Text = DateTime.Now.ToShortDateString();
            DtpTo.Text = DateTime.Now.ToShortDateString();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            tbl.Clear();

            //هذه الاكواد من اجل التواريخ من الى ورح اضيفهم في السلكت تحت
            string date1;
            string date2;
            date1 = DtpFrom.Value.ToString("yyyy-MM-dd");
            date2 = DtpTo.Value.ToString("yyyy-MM-dd");

            //هذه الحالات من ال اختيار مورد محدد او جميعهم وفي طل واحدة منهم خيار بكتابة رقم الفاتورة الذي اريد ان ابحث فيه
            if (rbtnAllSup.Checked == true)
            {
                if (checkOrderNumber.Checked == false)
                {
                    tbl = db.readData("SELECT [Order_ID] as'رقم الفاتورة',Suppliers.Sup_Name as'اسم المورد',Products.Pro_Name as'اسم المنتج',[Date] as'تاريخ الفاتورة',[Buy_Details].[Qty] as'الكمية'  ,[Price] as'السعر',[Discount] as'الخصم',[Total] as'اجمالي ',[TotalOrder] as'الاجمالي الفاتورة',[Madou3] as'المدفوع',[Bakey] as'المبلغ الباقي',[User_Name] as'اسم المستخدم'FROM [dbo].[Buy_Details],Suppliers,Products where [Buy_Details].Sup_ID = Suppliers.Sup_ID and [Buy_Details].Pro_ID =  Products.Pro_ID\r\n and Convert (date,Date,105) between '" + date1 + "' and '" + date2 + "' ORDER BY Order_ID ASC    ", "");
                }
                else if (checkOrderNumber.Checked == true)
                {
                    tbl = db.readData("SELECT [Order_ID] as'رقم الفاتورة',Suppliers.Sup_Name as'اسم المورد',Products.Pro_Name as'اسم المنتج',[Date] as'تاريخ الفاتورة',[Buy_Details].[Qty] as'الكمية'  ,[Price] as'السعر',[Discount] as'الخصم',[Total] as'اجمالي ',[TotalOrder] as'الاجمالي الفاتورة',[Madou3] as'المدفوع',[Bakey] as'المبلغ الباقي',[User_Name] as'اسم المستخدم'FROM [dbo].[Buy_Details],Suppliers,Products where [Buy_Details].Sup_ID = Suppliers.Sup_ID and [Buy_Details].Pro_ID =  Products.Pro_ID\r\n and Order_ID =" + txtOrderNumber.Text + " and Convert (date,Date,105) between '" + date1 + "' and '" + date2 + "'  ORDER BY Order_ID ASC ", "");

                }
            }
            else if (rbtnOneSup.Checked == true)
            {
                if (checkOrderNumber.Checked == false)
                {
                    tbl = db.readData("SELECT [Order_ID] as'رقم الفاتورة',Suppliers.Sup_Name as'اسم المورد',Products.Pro_Name as'اسم المنتج',[Date] as'تاريخ الفاتورة',[Buy_Details].[Qty] as'الكمية'  ,[Price] as'السعر',[Discount] as'الخصم',[Total] as'اجمالي ',[TotalOrder] as'الاجمالي الفاتورة',[Madou3] as'المدفوع',[Bakey] as'المبلغ الباقي',[User_Name] as'اسم المستخدم'FROM [dbo].[Buy_Details],Suppliers,Products where [Buy_Details].Sup_ID = Suppliers.Sup_ID and [Buy_Details].Pro_ID =  Products.Pro_ID\r\n and Convert (date,Date,105) between '" + date1 + "' and '" + date2 + "' and [Buy_Details].Sup_ID = " + cbxSupplier.SelectedValue + " ORDER BY Order_ID ASC ", "");

                }
                else if (checkOrderNumber.Checked == true)
                {
                    tbl = db.readData("SELECT [Order_ID] as'رقم الفاتورة',Suppliers.Sup_Name as'اسم المورد',Products.Pro_Name as'اسم المنتج',[Date] as'تاريخ الفاتورة',[Buy_Details].[Qty] as'الكمية'  ,[Price] as'السعر',[Discount] as'الخصم',[Total] as'اجمالي ',[TotalOrder] as'الاجمالي الفاتورة',[Madou3] as'المدفوع',[Bakey] as'المبلغ الباقي',[User_Name] as'اسم المستخدم'FROM [dbo].[Buy_Details],Suppliers,Products where [Buy_Details].Sup_ID = Suppliers.Sup_ID and [Buy_Details].Pro_ID =  Products.Pro_ID\r\n and Order_ID="+txtOrderNumber.Text+" and Convert (date,Date,105) between '" + date1 + "' and '" + date2 + "' and [Buy_Details].Sup_ID = " + cbxSupplier.SelectedValue + " ORDER BY Order_ID ASC ", "");

                }
            }
            DgvSearch.DataSource = tbl;

            //هذا الكود من اجل اظهار اجمالي مبلغ المشتريات 
            decimal totalPrice = 0;
            for(int i =0; i<= DgvSearch.Rows.Count - 1 ; i++)
            {
                totalPrice += Convert.ToDecimal(DgvSearch.Rows[i].Cells[7].Value);

            }
            txtTotal.Text = Math.Round(totalPrice, 2).ToString();
        }

        private void Print()
        {
            //هنا قلناله انه يطبع من الشاشة من المكان يلي واقف عليه
            int id = Convert.ToInt32(DgvSearch.CurrentRow.Cells[0].Value);

            DataTable tblRpt = new DataTable();

            tblRpt.Clear();
            //هذه من اجل قراءة المعلومات الموجودة لازم تكون نفسها يلي استخدمناها داخل مكان عمل الفاتورة
            tblRpt = db.readData("SELECT [Order_ID] as'رقم الفاتورة',Suppliers.Sup_Name as'اسم المورد',Products.Pro_Name as'اسم المنتج',[Date] as'تاريخ الفاتورة',[Buy_Details].[Qty] as'الكمية',[User_Name] as'اسم المستخدم',[Price] as'السعر',[Discount] as'الخصم',[Total] as'اجمالي الصنف',[TotalOrder] as'الاجمالي العام',[Madou3] as'المدفوع',[Bakey] as'المبلغ الباقي' FROM [dbo].[Buy_Details],Suppliers,Products where Suppliers.Sup_ID = [Buy_Details].Sup_ID and Products.Pro_ID = [Buy_Details].Pro_ID and Order_ID=" + id + " ", "");

            Frm_Printing frm = new Frm_Printing();
            RptOrderBut rpt = new RptOrderBut();

            //هذه الدالة من اجل عمل رفرش للصفحة من اجل اعادة تحميل البيانات فيها لان رح نستخدمها اكتر من مرة
            //وهنا من اجل عرض هذه crystalReportViewer2 => modifires => public
            frm.crystalReportViewer2.RefreshReport();

            //هذه الدالة مهمة جدا من اجل عند فتح الفاتورة عند جهاز العميل سوف تظهر مشكلة ويلي هي قاعدة البيانات رح يطلب اسم المستخدم وكلمة السر ولو دخلتهم ما رح يمشي الحال من اجل حل المشكلة رح نعمل هيك كود رح يطلب 4 متغيرات اسم المستخدم تبعت قاعدة البيانات واسم المستخدم تبعت قاعدة البيانات واسم اسيرفر تبعيواسم قاعدةالبيانات تبعتي
            rpt.SetDatabaseLogon("", "", "LAPTOP-ITEHASQ2", "Sales_System");
            rpt.SetDataSource(tblRpt);
            //لقد قمنا هنا ب عمل اد بطريقة parameter fields => new => name = id 
            //ولقد سويناه لرقم الفاتورة ليتزامنو وذهبنا الى خصائصه بعد ما وجدناه وجعلناه يساويرقم ال اد للفاتورة من اجل ان يتغير عند عمل كل فاتورة وممكن ان اغير بخصائص ال اد للشكل الذي اريده
            rpt.SetParameterValue("ID", id);
            //هاد الكود من اجل ان يظهر الفاتورة يلي صممناها داخل ال frm_printing
            frm.crystalReportViewer2.ReportSource = rpt;


            //هذا الكود من اجل طباعة الفاتورة في الجهاز ونقله الى pdf
            System.Drawing.Printing.PrintDocument printDocument = new System.Drawing.Printing.PrintDocument();
            rpt.PrintOptions.PrinterName = printDocument.PrinterSettings.PrinterName;
            //من اجل الطياعة المباشرة بدها اربع برميتري الاول كم عدد النسخ ولازم ترو وصفحة البداي والصفحة النهاية رح يكونو صفر بعدين رح نتعمق فيهم اكتر
            //rpt.PrintToPrinter(1, true, 0, 0);

            frm.ShowDialog();

        }

        private void btnPrintOrder_Click(object sender, EventArgs e)
        {
            if (DgvSearch.Rows.Count >=1)
            {
                Print();
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if(DgvSearch.Rows.Count >= 1)
            {
                if (MessageBox.Show("هل انت متأكد من مسح البيانات", "تحذير!!!", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                {
                    db.exceuteData("delete from Buy where Order_ID=" + DgvSearch.CurrentRow.Cells[0].Value + " ", "تم المسح بنجاح");

                    btnSearch_Click(null, null);
                }
            }
        }

        private void PrintAll()
        {
            string date1;
            string date2;
            date1 = DtpFrom.Value.ToString("yyyy-MM-dd");
            date2 = DtpTo.Value.ToString("yyyy-MM-dd");

            DataTable tblRpt = new DataTable();

            tblRpt.Clear();
            //هذه من اجل قراءة المعلومات الموجودة لازم تكون نفسها يلي استخدمناها داخل مكان عمل الفاتورة
            tblRpt = db.readData("SELECT [Order_ID] as'رقم الفاتورة',Suppliers.Sup_Name as'اسم المورد',Products.Pro_Name as'اسم المنتج',[Date] as'تاريخ الفاتورة',[Buy_Details].[Qty] as'الكمية'  ,[Price] as'السعر',[Discount] as'الخصم',[Total] as'اجمالي ',[TotalOrder] as'الاجمالي الفاتورة',[Madou3] as'المدفوع',[Bakey] as'المبلغ الباقي',[User_Name] as'اسم المستخدم'FROM [dbo].[Buy_Details],Suppliers,Products where [Buy_Details].Sup_ID = Suppliers.Sup_ID and [Buy_Details].Pro_ID =  Products.Pro_ID and Convert (date,Date,105) between '" + date1 + "' and '" + date2 + "' ORDER BY Order_ID ASC ", "");

            try
            {
                Frm_Printing frm = new Frm_Printing();
                RptBuyReport rpt = new RptBuyReport();

                //هذه الدالة من اجل عمل رفرش للصفحة من اجل اعادة تحميل البيانات فيها لان رح نستخدمها اكتر من مرة
                //وهنا من اجل عرض هذه crystalReportViewer2 => modifires => public
                frm.crystalReportViewer2.RefreshReport();

                //هذه الدالة مهمة جدا من اجل عند فتح الفاتورة عند جهاز العميل سوف تظهر مشكلة ويلي هي قاعدة البيانات رح يطلب اسم المستخدم وكلمة السر ولو دخلتهم ما رح يمشي الحال من اجل حل المشكلة رح نعمل هيك كود رح يطلب 4 متغيرات اسم المستخدم تبعت قاعدة البيانات واسم المستخدم تبعت قاعدة البيانات واسم اسيرفر تبعيواسم قاعدةالبيانات تبعتي
                rpt.SetDatabaseLogon("", "", "LAPTOP-ITEHASQ2", "Sales_System");
                rpt.SetDataSource(tblRpt);

                //هذه الاكواد من اجل اخد التواريخ على حسب ما سوف يدخلهم المستخدم وهدول عملاناهم من خلال اضافة باراميتري من شاشة الفاتورة
                rpt.SetParameterValue("From", date1);
                rpt.SetParameterValue("To", date2);

                //هاد الكود من اجل ان يظهر الفاتورة يلي صممناها داخل ال frm_printing
                frm.crystalReportViewer2.ReportSource = rpt;


                //هذا الكود من اجل طباعة الفاتورة في الجهاز ونقله الى pdf
                System.Drawing.Printing.PrintDocument printDocument = new System.Drawing.Printing.PrintDocument();
                rpt.PrintOptions.PrinterName = printDocument.PrinterSettings.PrinterName;
                //من اجل الطياعة المباشرة بدها اربع برميتري الاول كم عدد النسخ ولازم ترو وصفحة البداي والصفحة النهاية رح يكونو صفر بعدين رح نتعمق فيهم اكتر
                //rpt.PrintToPrinter(1, true, 0, 0);

                frm.ShowDialog();


            }
            catch (Exception ) { }
           
        }

        private void btnPrintAll_Click(object sender, EventArgs e)
        {
            if(DgvSearch.Rows.Count>=1)
            {
                PrintAll();
            }
        }
    }
}