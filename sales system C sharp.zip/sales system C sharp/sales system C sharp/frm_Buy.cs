﻿using System;
using System.Data;
using System.Windows.Forms;

namespace sales_system_C_sharp
{
    public partial class frm_Buy : DevExpress.XtraEditors.XtraForm
    {
        //هذه الدالة عبارة عن انه تسمحلي بنقل المعلومات من شاشة الى شاشة اخرى داخل تشغيل البرنامج
        private static frm_Buy frm;
        static void frm_FormClosed(object sender, FormClosedEventArgs e)
        {
            frm = null;
        }
        public static frm_Buy GetFormBuy
        {
            get
            {
                if (frm == null)
                {
                    frm = new frm_Buy();
                    frm.FormClosed += new FormClosedEventHandler(frm_FormClosed);
                }
                return frm;
            }
        }

        public frm_Buy()
        {
            InitializeComponent();
            //هنا يقول ازا الدالة يلي فوق فاضية يسوي بس العملية هون
            if (frm == null)
                frm = this;
        }
        Database_class db = new Database_class();
        DataTable tbl = new DataTable();
        //هنا عند الضغط مرتين على ال فورم مشان الرقم التلقائي
        private void AutoNumber()
        {
            tbl.Clear();
            tbl = db.readData("select max (Order_ID) from Buy", "");

            if ((tbl.Rows[0][0].ToString() == DBNull.Value.ToString()))
            {
                txtID.Text = "1";
            }
            else
            {
                txtID.Text = (Convert.ToInt32(tbl.Rows[0][0]) + 1).ToString();
            }
            DtpDate.Text = DateTime.Now.ToShortDateString();
            DtpAagel.Text = DateTime.Now.ToShortDateString();

            try
            {
                cbxItems.SelectedIndex = 0;
                cbxSupplier.SelectedIndex = 0;
            }
            catch (Exception) { }
            cbxItems.Text = " اختر منتج ";
            DgvBuy.Rows.Clear();
            rbtnCash.Checked = true;
            txtbarcode.Clear();
            //من اجل يسولها فوكس يعني لما اختار تضل الماوس هنيك
            txtbarcode.Focus();
            txtTotal.Clear();

        }
        private void FillItems()
        {
            cbxItems.DataSource = db.readData("select * from Products", "");
            cbxItems.DisplayMember = "Pro_Name";
            cbxItems.ValueMember = "Pro_ID";
        }
        //هنا سويناها بابلك من اجل استخدامها في frm_suppliers
        //من اجل مناداة المعلومات
        public void FillSupplier()
        {
            cbxSupplier.DataSource = db.readData("select * from Suppliers", "");
            cbxSupplier.DisplayMember = "Sup_Name";
            cbxSupplier.ValueMember = "Sup_ID";
        }
        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void label14_Click(object sender, EventArgs e)
        {

        }

        private void txtID_TextChanged(object sender, EventArgs e)
        {

        }
        //هذه الدالة عند فتح شاشة المشتريات ان يحضر المعلومات
        private void frm_Buy_Load(object sender, EventArgs e)
        {
            FillItems();
            FillSupplier();
            try
            {
                AutoNumber();
            }
            catch (Exception) { }

        }
        //هذه الدالة هي تتحقق عند ضغطعلى ثلاث نقاط جنب المورد من اجل اضافة مورد
        private void btnSuppliersbrowse_Click(object sender, EventArgs e)
        {

            frm_suppliers frm = new frm_suppliers();
            frm.ShowDialog();
        }

        private void btnItems_Click(object sender, EventArgs e)
        {
            if (cbxItems.Text == " اختر منتج ")
            {
                MessageBox.Show("من فضلك اختر منتج", "تاكيد", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            if (cbxItems.Items.Count <= 0)
            {

                MessageBox.Show("من فضلك اختر النتجات اولا", "تاكيد", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            //(Products) هنا عند اختيار اي من المنتجات رح يتم عرض معلومات المنتجات بالتفصيل الموجودة في خانة 
            DataTable tblItem = new DataTable();
            tblItem.Clear();

            tblItem = db.readData("select * from Products where Pro_ID= " + cbxItems.SelectedValue + " ", "");
            if (tblItem.Rows.Count >= 1)
            {
                try
                {
                    string Product_ID = tblItem.Rows[0][0].ToString();
                    string Product_Name = tblItem.Rows[0][1].ToString();
                    string Product_Qty = "1";//من اجل الكمية انها تكون دائما واحد ورح نسمح بتعديل الكمية لاحقا من اجل شراء الكمية التي اريدها
                    string Product_Price = tblItem.Rows[0][3].ToString();
                    decimal Discount = 0;

                    decimal total = Convert.ToDecimal(Product_Qty) * Convert.ToDecimal(tblItem.Rows[0][3]);

                    DgvBuy.Rows.Add(1);
                    int rowindex = DgvBuy.Rows.Count - 1;
                    //هنا بسبب ال انديكس قمنا بتنقيص واحد
                    DgvBuy.Rows[rowindex].Cells[0].Value = Product_ID;
                    //سيل يلي هو الخلية يلي هو العامود ب (د ج ف) من اجل عرض البيانات يلي خزنتها جوا الكويري يلي في الاعلى
                    DgvBuy.Rows[rowindex].Cells[1].Value = Product_Name;
                    DgvBuy.Rows[rowindex].Cells[2].Value = Product_Qty;
                    DgvBuy.Rows[rowindex].Cells[3].Value = Product_Price;
                    DgvBuy.Rows[rowindex].Cells[4].Value = Discount;
                    DgvBuy.Rows[rowindex].Cells[5].Value = total;




                }
                catch (Exception) { }


                try
                {
                    decimal TotalOrder = 0;
                    for (int i = 0; i <= DgvBuy.Rows.Count - 1; i++)
                    {
                        TotalOrder += Convert.ToDecimal(DgvBuy.Rows[i].Cells[5].Value);
                        //هاد الكود رح يكون عند اضافة منتج الخط الاصفر رح يكون على الخانة المضافة جديدا
                        DgvBuy.ClearSelection();
                        DgvBuy.FirstDisplayedScrollingRowIndex = DgvBuy.Rows.Count - 1;
                        DgvBuy.Rows[DgvBuy.Rows.Count - 1].Selected = true;
                    
                    }
                    txtTotal.Text = Math.Round(TotalOrder, 2).ToString();
                    //هنا لقد جمعنا الاجمالي ووضعناه في اجمالي المطلوب وهذه ال ماث راوند من اجل وضع فاصلة والارقام التي بعد الفاصلة 2 فقط
                    lblItemscount.Text = (DgvBuy.Rows.Count).ToString();
                    //هذه من اجل تعديل عدد الاصناف وطبعا كل هذه العمليات نحن نريد تحقيقها عند الضغط على الزر التنزيل يلي جنب اختر منتج

                }
                catch (Exception) { }


            }


        }

        private void cbxItems_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnDeleteItems_Click(object sender, EventArgs e)
        {
            if (DgvBuy.Rows.Count >= 1)
            {
                int index = DgvBuy.SelectedRows[0].Index;
                DgvBuy.Rows.RemoveAt(index);

                if (DgvBuy.Rows.Count <= 0)
                {
                    txtTotal.Text = "0";
                }
                //لقد عدنا ووضعناه هنا من اجل عند المسح الصف يلي انا بدي ياه
                try
                {
                    decimal TotalOrder = 0;
                    for (int i = 0; i <= DgvBuy.Rows.Count - 1; i++)
                    {
                        TotalOrder += Convert.ToDecimal(DgvBuy.Rows[i].Cells[5].Value);
                        //هاد الكود رح يكون عند اضافة منتج الخط الاصفر رح يكون على الخانة المضافة جديدا
                        DgvBuy.ClearSelection();
                        DgvBuy.FirstDisplayedScrollingRowIndex = DgvBuy.Rows.Count - 1;
                        DgvBuy.Rows[DgvBuy.Rows.Count - 1].Selected = true;

                    }
                    txtTotal.Text = Math.Round(TotalOrder, 2).ToString();
                    //هنا لقد جمعنا الاجمالي ووضعناه في اجمالي المطلوب وهذه ال ماث راوند من اجل وضع فاصلة والارقام التي بعد الفاصلة 2 فقط
                    lblItemscount.Text = (DgvBuy.Rows.Count).ToString();
                    //هذه من اجل تعديل عدد الاصناف وطبعا كل هذه العمليات نحن نريد تحقيقها عند الضغط على الزر التنزيل يلي جنب اختر منتج

                }
                catch (Exception) { }
            }

        }

        private void txtbarcode_KeyPress(object sender, KeyPressEventArgs e)
        {
            //هلق نبي ننشئ عند ضغط زر انتر يعمل باركود اوتوماتيكي فمن اجل الضغط على زر انت يوجد كود ولكل زرار في ولوحة المفاتيح يوجد لها كود مثال عن زر المسح
            //in google:asckii code delete button
            //
            if (e.KeyChar == 13)
            {
                //(Products) هنا عند اختيار اي من المنتجات رح يتم عرض معلومات المنتجات بالتفصيل الموجودة في خانة 
                DataTable tblItem = new DataTable();
                tblItem.Clear();

                tblItem = db.readData("select * from Products where Barcode=N '" + txtbarcode.Text + "' ", "");
                if (tblItem.Rows.Count >= 1)
                {
                    try
                    {
                        string Product_ID = tblItem.Rows[0][0].ToString();
                        string Product_Name = tblItem.Rows[0][1].ToString();
                        string Product_Qty = "1";//من اجل الكمية انها تكون دائما واحد ورح نسمح بتعديل الكمية لاحقا من اجل شراء الكمية التي اريدها
                        string Product_Price = tblItem.Rows[0][3].ToString();
                        decimal Discount = 0;

                        decimal total = Convert.ToDecimal(Product_Qty) * Convert.ToDecimal(tblItem.Rows[0][3]);

                        DgvBuy.Rows.Add(1);
                        int rowindex = DgvBuy.Rows.Count - 1;
                        //هنا بسبب ال انديكس قمنا بتنقيص واحد
                        DgvBuy.Rows[rowindex].Cells[0].Value = Product_ID;
                        //سيل يلي هو الخلية يلي هو العامود ب (د ج ف) من اجل عرض البيانات يلي خزنتها جوا الكويري يلي في الاعلى
                        DgvBuy.Rows[rowindex].Cells[1].Value = Product_Name;
                        DgvBuy.Rows[rowindex].Cells[2].Value = Product_Qty;
                        DgvBuy.Rows[rowindex].Cells[3].Value = Product_Price;
                        DgvBuy.Rows[rowindex].Cells[4].Value = Discount;
                        DgvBuy.Rows[rowindex].Cells[5].Value = total;




                    }
                    catch (Exception) { }


                    try
                    {
                        decimal TotalOrder = 0;
                        for (int i = 0; i <= DgvBuy.Rows.Count - 1; i++)
                        {
                            TotalOrder += Convert.ToDecimal(DgvBuy.Rows[i].Cells[5].Value);
                        }
                        txtTotal.Text = Math.Round(TotalOrder, 2).ToString();
                        //هنا لقد جمعنا الاجمالي ووضعناه في اجمالي المطلوب وهذه ال ماث راوند من اجل وضع فاصلة والارقام التي بعد الفاصلة 2 فقط
                        lblItemscount.Text = (DgvBuy.Rows.Count).ToString();
                        //هذه من اجل تعديل عدد الاصناف وطبعا كل هذه العمليات نحن نريد تحقيقها عند الضغط على الزر التنزيل يلي جنب اختر منتج

                    }
                    catch (Exception) { }


                }
            }
        }
        private void PayOrder()
        {
            if (DgvBuy.Rows.Count >= 1)
            {
                if (cbxSupplier.Items.Count <= 0)
                {
                    MessageBox.Show("من فضلك اختر مورد اولا", "تاكيد");
                    return;
                }
                try
                {
                    if (DgvBuy.Rows.Count >= 1)
                    {
                        Properties.Settings.Default.TotalOrder = Convert.ToDecimal(txtTotal.Text);
                        Properties.Settings.Default.Madfou3 = 0;
                        Properties.Settings.Default.Bakey = 0;
                        Properties.Settings.Default.Save();

                        Frm_PayBuy frm = new Frm_PayBuy();
                        frm.ShowDialog();
                    }

                    if (Properties.Settings.Default.CheckButton == true)
                    {
                        //هذا الكود من اجل طبع الفاتورة الان رح نضيف الخانات الجديدة يلي ضفناها من اجل اف12
                        string d = DtpDate.Value.ToString("dd/MM/yyyy");
                        string dreminder = DtpAagel.Value.ToString("dd/MM/yyyy");
                        db.exceuteData("insert into Buy values (" + txtID.Text + ", N'" + d + "'," + cbxSupplier.SelectedValue + " )", "");

                        for (int i = 0; i <= DgvBuy.Rows.Count - 1; i++)
                        {
                            db.exceuteData("insert into Buy_Details values (" + txtID.Text + ", " + cbxSupplier.SelectedValue + ", " + DgvBuy.Rows[i].Cells[0].Value + ", N'" + d + "', " + DgvBuy.Rows[i].Cells[2].Value + ", '123', " + DgvBuy.Rows[i].Cells[3].Value + ", " + DgvBuy.Rows[i].Cells[4].Value + ", " + DgvBuy.Rows[i].Cells[5].Value + "," + txtTotal.Text + "," + Properties.Settings.Default.Madfou3 + "," + Properties.Settings.Default.Bakey + " )", "");
                            //الان لما اشتري منتج من شاشة المشتريات ما رح تزيد كمية المنتج في جدول المنتجات فمن اجل حل هذه المشكلة يجب عمل هذا لكود يلي في الاسفل وطبعا رح نسق انه عن شراء نفس النتج الي موجود عندي سابقا انه يزيد عليه نفسه
                            db.exceuteData("update Products set Qty = Qty + " + DgvBuy.Rows[i].Cells[2].Value +" where Pro_ID="+ DgvBuy.Rows[i].Cells[0].Value + " ", "");
                        
                        }

                        if(rbtnCash.Checked == true)
                        {
                            db.exceuteData("insert into Supplier_Report values ("+txtID.Text+","+Properties.Settings.Default.Madfou3+",'"+d+"',"+cbxSupplier.SelectedValue+")", "");
                        }
                        else if(rbtnAagel.Checked == true){
                            //هنا عند الدفع عند الاجل يوجد حالتان ان المبلغ كامل رح يتسجل دديون في الكود الاول او يندفع منه شوي يلي هو اكتر من 1 ورح يحط يلي اندفع في الجدول في س ك ل في الكود الثاني
                            //هو الجدول بحيث يعطيني المبلغالباقي يلي لازم ادفعلهم للموردين Supplier_Money 
                            //هو الجدول يلي فيه البيانات يلي انا قمت بالدفع للموردين Supplier_Report
                            db.exceuteData("insert into Supplier_Money values (" + txtID.Text + "," + cbxSupplier.SelectedValue + "," + Properties.Settings.Default.Bakey + ",'" + d + "','" + dreminder + "') ", "");
                           
                            if(Properties.Settings.Default.Madfou3 >= 1)
                            {
                                db.exceuteData("insert into Supplier_Report values (" + txtID.Text + "," + Properties.Settings.Default.Madfou3 + ",'" + d + "'," + cbxSupplier.SelectedValue + ")", "");
                            }
                        }

                        Print();

                        AutoNumber();
                    }
                }
                catch (Exception) { }
            }
        }
        //to print 8 cm order هذه من الدالة من اجل طباعة الفواتير
        private void Print()
        {
            int id =Convert.ToInt32( txtID.Text);
            
            DataTable tblRpt = new DataTable();
            
            tblRpt.Clear();
            //هذه من اجل قراءة المعلومات الموجودة لازم تكون نفسها يلي استخدمناها داخل مكان عمل الفاتورة
            tblRpt = db.readData("SELECT [Order_ID] as'رقم الفاتورة',Suppliers.Sup_Name as'اسم المورد',Products.Pro_Name as'اسم المنتج',[Date] as'تاريخ الفاتورة',[Buy_Details].[Qty] as'الكمية',[User_Name] as'اسم المستخدم',[Price] as'السعر',[Discount] as'الخصم',[Total] as'اجمالي الصنف',[TotalOrder] as'الاجمالي العام',[Madou3] as'المدفوع',[Bakey] as'المبلغ الباقي' FROM [dbo].[Buy_Details],Suppliers,Products where Suppliers.Sup_ID = [Buy_Details].Sup_ID and Products.Pro_ID = [Buy_Details].Pro_ID and Order_ID="+id+" ", "");

            try
            {
                Frm_Printing frm = new Frm_Printing();

                RptOrderBut rpt = new RptOrderBut();


                //هذه الدالة من اجل عمل رفرش للصفحة من اجل اعادة تحميل البيانات فيها لان رح نستخدمها اكتر من مرة
                //وهنا من اجل عرض هذه crystalReportViewer2 => modifires => public
                frm.crystalReportViewer2.RefreshReport();

                //هذه الدالة مهمة جدا من اجل عند فتح الفاتورة عند جهاز العميل سوف تظهر مشكلة ويلي هي قاعدة البيانات رح يطلب اسم المستخدم وكلمة السر ولو دخلتهم ما رح يمشي الحال من اجل حل المشكلة رح نعمل هيك كود رح يطلب 4 متغيرات اسم المستخدم تبعت قاعدة البيانات واسم المستخدم تبعت قاعدة البيانات واسم اسيرفر تبعيواسم قاعدةالبيانات تبعتي
                rpt.SetDatabaseLogon("", "", "LAPTOP-ITEHASQ2", "Sales_System");
                rpt.SetDataSource(tblRpt);
                //لقد قمنا هنا ب عمل اد بطريقة parameter fields => new => name = id 
                //ولقد سويناه لرقم الفاتورة ليتزامنو وذهبنا الى خصائصه بعد ما وجدناه وجعلناه يساويرقم ال اد للفاتورة من اجل ان يتغير عند عمل كل فاتورة وممكن ان اغير بخصائص ال اد للشكل الذي اريده
                rpt.SetParameterValue("ID", id);
                //هاد الكود من اجل ان يظهر الفاتورة يلي صممناها داخل ال frm_printing
                frm.crystalReportViewer2.ReportSource = rpt;


                //هذا الكود من اجل طباعة الفاتورة في الجهاز ونقله الى pdf
                System.Drawing.Printing.PrintDocument printDocument = new System.Drawing.Printing.PrintDocument();
                rpt.PrintOptions.PrinterName = printDocument.PrinterSettings.PrinterName;
                //من اجل الطياعة المباشرة بدها اربع برميتري الاول كم عدد النسخ ولازم ترو وصفحة البداي والصفحة النهاية رح يكونو صفر بعدين رح نتعمق فيهم اكتر
                rpt.PrintToPrinter(1, true, 0, 0);

                //frm.ShowDialog();

            }
            catch (Exception) { }
            
        }

        private void UpdateQty()
        {
            if (DgvBuy.Rows.Count >= 1)
            {
                int index = DgvBuy.SelectedRows[0].Index;
                //الان سوف اكتب كود يممر البيانات من هنا الى الفورم تبع اف 11 ورح 
                //هنا ان نختار روز من سيل يلي هي الخانة الثانية وطبعا عند الضفط عللا اف11 رح يطلعغ على حسب ما وين انا كابس في الفارة القسم الاصفر
                Properties.Settings.Default.Item_Qty = Convert.ToDecimal(DgvBuy.Rows[index].Cells[2].Value);
                Properties.Settings.Default.Item_BuyPrice = Convert.ToDecimal(DgvBuy.Rows[index].Cells[3].Value);
                Properties.Settings.Default.Item_Discount = Convert.ToDecimal(DgvBuy.Rows[index].Cells[4].Value);
                //بهذه الطريقة سوف نحفظ الخصائص ويوجد ايضا نفسها بس بدل سيف يوجد (ريسيت) من اجل وضع المعلومات الديفولت يلي ضفتها في قائما الاعدادات في الخصائص
                Properties.Settings.Default.Save();

                

                Frm_BuyQty frm = new Frm_BuyQty();
                frm.ShowDialog();
            }
        }

        private void frm_Buy_KeyDown(object sender, KeyEventArgs e)
        {
            //الخاصية يلي انا فيها من اجل الضغط على اي زرار من اجل زر ف12
            if (e.KeyCode == Keys.F12)
            {
                PayOrder();
            }
            else if (e.KeyCode == Keys.F11)
            {
                UpdateQty();

                try
                {
                    //لقد فمنا باضافة هاد الكود من اجل ضمان تخلص من مشاكل بتعديل الكمية ممكن ان  تحصل
                    int index = DgvBuy.SelectedRows[0].Index;

                    DgvBuy.Rows[index].Cells[2].Value = Properties.Settings.Default.Item_Qty;
                    DgvBuy.Rows[index].Cells[3].Value = Properties.Settings.Default.Item_BuyPrice;
                    DgvBuy.Rows[index].Cells[4].Value = Properties.Settings.Default.Item_Discount;


                }
                catch (Exception) { }
            }
        }

        private void DgvBuy_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            //هنا الحدث عندما يتم تغير في القيم العاميد تبع DgvBuy
            //واظهار الاجمالي بشكل صحيح
            decimal Item_Qty = 0, Item_BuyPrice = 0, Item_Discount = 0;
            try
            {
                int index = DgvBuy.SelectedRows[0].Index;

                Item_Qty = Convert.ToDecimal(DgvBuy.Rows[index].Cells[2].Value);
                Item_BuyPrice = Convert.ToDecimal(DgvBuy.Rows[index].Cells[3].Value);
                Item_Discount = Convert.ToDecimal(DgvBuy.Rows[index].Cells[4].Value);

                decimal Total = 0;
                Total = (Item_Qty * Item_BuyPrice) - Item_Discount;

                DgvBuy.Rows[index].Cells[5].Value = Total;

                //وهنا هاد الكود يحسب الاجمالي المطلوب عند تغير اي عدد في الخانات
                decimal TotalOrder = 0;
                for (int i = 0; i <= DgvBuy.Rows.Count - 1; i++)
                {
                    TotalOrder += Convert.ToDecimal(DgvBuy.Rows[i].Cells[5].Value);
                }
                txtTotal.Text = Math.Round(TotalOrder, 2).ToString();

            }
            catch (Exception) { }
        }
    }
}